package DBUtils;

import MazeUtils.MazeDataTypes.Maze;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

/**
 * This class uses MazeDataSource and its methods to retrieve / store data from the database
 * @author Nin Kao (n10212469)
 */
public class MazeData {
    DefaultListModel<String> listModel;
    DefaultTableModel tableModel;
    DefaultTableModel tableModel2;
    DefaultTableModel searchModel;
    mazeDataSource mazeData;

    /**
     * Constructor initializes the models and
     * attempts to read any data saved from previous
     * invocations of the application.
     *
     * @author Nin Kao (n10212469)
     */
    public MazeData() {
        //initializing objects
        listModel = new DefaultListModel<>();
        tableModel = new DefaultTableModel();
        tableModel2 = new DefaultTableModel();
        mazeData = new mazeDataBase();

        // add the retrieved data to the list model
        for (String name : mazeData.getMazeList()) {
            listModel.addElement(name);
        }

        //add the retrieved data to the table model
        //A table with maze details in mazeDataBase
        //"ID", "Author", "Name"
        tableModel = mazeData.getTable();

        //add the retrieved data to the table model
        //A table with maze details in mazeDataBase
        //"ID", "Author", "Name", "created_date", "updated_date"
        tableModel2 = mazeData.getTablewithDate();

    }

    /**
     * Accessor for the list model.
     *
     * @return the listModel to display.
     * @author Nin Kao (n10212469)
     */
    public ListModel<String> getModel() {
        return listModel;
    }

    /**
     * Accessor for the table model
     *
     * @return in tableModel to display in MazeExport
     * @author Nin Kao (n10212469)
     */
    public TableModel tableModel() {
        return tableModel;
    }

    /**
     * Accessor for the table model
     *
     * @return in tableModel to display in dbBrowse
     * @author Nin Kao (n10212469)
     */
    public TableModel tableModelwithDate() {
        return tableModel2;
    }

    /**
     * Accessor for the search model
     *
     * @param maze_name search maze name input
     * @return in searchModel to display
     * @author Nin Kao (n10212469)
     */
    public TableModel searchModel(String maze_name) {
        searchModel = mazeData.searchTable(maze_name);
        return searchModel;
    }

    /**
     * Accessor of the getMazeObject
     *
     * @param maze_id search maze with maze id
     * @return Maze object
     * @author Nin Kao (n10212469)
     */
    public Maze getMazeObject(int maze_id) {
        return mazeData.getMazeObject(maze_id);
    }

}
