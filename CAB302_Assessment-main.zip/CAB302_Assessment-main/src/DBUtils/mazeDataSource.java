package DBUtils;

import MazeUtils.MazeDataTypes.Maze;

import javax.swing.table.DefaultTableModel;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Set;

/**
 * Interface for MazeDataBase methods
 */
public interface mazeDataSource {
    /**
     * Adds a Maze to the maze list, if they are not already in the list
     *
     * @param maze Maze to add
     * @author Nin Kao (n10212469)
     */
    void createMaze(Maze maze) throws SQLException, IOException;

    /**
     * Deletes a Maze from the address book.
     *
     * @param id The id to delete from the maze list.
     * @return returns true if deletion is successful
     * @author Nin Kao (n10212469)
     */
    Boolean deleteMaze(int id);

    /**
     * Extracts all the details of a Maze from the maze database based on the
     * id passed in.
     *
     * @param id The id as an Integer to search for.
     * @return all details in a Maze object for the id
     * @author Nin Kao (n10212469)
     */
    Maze getMaze(int id);

    /**
     * Retrieves a set of mazes from the database.
     *
     * @return set of mazes.
     * @author Nin Kao (n10212469)
     */
    Set<String> getMazeList();

    /**
     * Retrieves a table model from the data source.
     *
     * @return table model.
     * @author Nin Kao (n10212469)
     */
    DefaultTableModel getTable();

    /**
     * Retrieves a table model with created/updated Date from the data source.
     *
     * @return table model.
     * @author Nin Kao (n10212469)
     */
    DefaultTableModel getTablewithDate();

    /**
     * Retrieves a table model from the
     * data source based on user search text input.
     *
     * @return table model.
     */
    DefaultTableModel searchTable(String maze_name);

    /**
     * Retrieves Maze object from the data source based on maze id.
     *
     * @param maze_id The ID of the maze in the database
     * @return maze the maze object to be retrieved
     * @author Nin Kao (n10212469)
     */
    Maze getMazeObject(int maze_id);

    void UpdateMaze(int id, Maze maze);
}
