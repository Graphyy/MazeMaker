package DBUtils;

import MazeUtils.MazeDataTypes.Maze;

import javax.swing.table.DefaultTableModel;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.sql.*;
import java.util.Set;
import java.util.TreeSet;

/**
 * Handles instances of database connections and operations done on their associated tables.
 */
public class mazeDataBase implements mazeDataSource {

    // Prepared statements to do a limited range of database operations.
    private static final String CREATE_TABLE = // Query to create a mazeco table on the server if one does not already exist
            "CREATE TABLE IF NOT EXISTS mazeco ("
                    + " id INT NOT NULL AUTO_INCREMENT,"
                    + "author VARCHAR(64) DEFAULT \"\","
                    + "name VARCHAR(64) NOT NULL,"
                    + "height INT NOT NULL,"
                    + "width INT NOT NULL,"
                    + "mazeData LONGBLOB NOT NULL,"
                    + "created TIMESTAMP NOT NULL,"
                    + "lastUpdate TIMESTAMP,"
                    + "PRIMARY KEY (id)"
                    + ");";
    private static final String INSERT_MAZE = "INSERT INTO mazeco (author, name, height, width, mazeData, created, lastUpdate) VALUES (?, ?, ?, ?, ?, ?, ?);";

    private static final String DELETE_MAZE = "DELETE FROM mazeco WHERE id=?";

    private static final String LOAD_MAZE = "SELECT * FROM mazeco WHERE id=?";

    private static final String MAZE_NAMES = "SELECT name FROM mazeco";

    private static final String MAZE_TABLE = "SELECT * FROM mazeco";

    private static final String MAZE_SEARCH = "SELECT * FROM mazeco WHERE name LIKE ?";

    private static final String MAZE_UPDATE = "UPDATE mazeco SET mazeData = ?, created = ?, lastUpdate = ? WHERE id = ?";

    private static final String MAZE_ID = "SELECT id FROM mazeco WHERE name LIKE ?";

    private static final String DROP_TABLE = "DROP TABLE IF EXISTS mazeco";
    final Connection conn;
    private PreparedStatement addMaze;
    private PreparedStatement delMaze;
    private PreparedStatement loadMaze;
    private PreparedStatement listMazes;
    private PreparedStatement tableMaze;
    private PreparedStatement searchMaze;
    private PreparedStatement getMazeID;
    private PreparedStatement dropTable;
    private PreparedStatement updateMaze;

    /**
     * Constructs a new mazeDataBase object, initialising a database connection and ensuring that there is a mazeco table on the server.
     */
    public mazeDataBase() {
        conn = DBConnection.getInstance();
        try {
            Statement init = conn.createStatement();
            init.execute(CREATE_TABLE);
            addMaze = conn.prepareStatement(INSERT_MAZE);

            // delete maze from db
            delMaze = conn.prepareStatement(DELETE_MAZE);

            //get individual maze from db
            loadMaze = conn.prepareStatement(LOAD_MAZE);

            //get a list of maze(id, name) from db
            listMazes = conn.prepareStatement(MAZE_NAMES);

            //get a table of maze from db
            tableMaze = conn.prepareStatement(MAZE_TABLE);

            //search maze and get a table from db
            searchMaze = conn.prepareStatement(MAZE_SEARCH);

            // Get Maze ID from Maze Name
            getMazeID = conn.prepareStatement(MAZE_ID);

            // Drop Mazeco table
            dropTable = conn.prepareStatement(DROP_TABLE);

            // Update maze data
            updateMaze = conn.prepareStatement(MAZE_UPDATE);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * Methods used for Unit Testing
     *
     */
    public void disableAutoCommit() throws SQLException {
        conn.setAutoCommit(false);
    }

    public void rollBack() throws SQLException {
        conn.rollback();
    }

    public void dropTable() throws SQLException {
        dropTable.executeUpdate();
    }


    /**
     * Create a new maze entry in the database
     *
     * @param maze {Maze} The maze to insert into the database
     */
    public void createMaze(Maze maze) throws SQLException, IOException, NullPointerException {
        addMaze.setString(1, maze.getAuthor());
        addMaze.setString(2, maze.getName());
        addMaze.setInt(3, maze.getHeight());
        addMaze.setInt(4, maze.getWidth());
        addMaze.setBytes(5, maze.getOutputStream());
        addMaze.setTimestamp(6, java.sql.Timestamp.valueOf(maze.getCreateTime()));
        addMaze.setTimestamp(7, java.sql.Timestamp.valueOf(maze.getLastEditTime()));
        addMaze.execute();
    }

    /**
     * Drop a given maze from the table
     *
     * @param id {int} id of the table to drop
     *           return true if deleted; false otherwise (nothing to delete)
     * @return Boolean
     */
    public Boolean deleteMaze(int id) throws NullPointerException {
        try {
            delMaze.setInt(1, id);
            int deleted = delMaze.executeUpdate();
            return deleted != 0;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public int getMazeId(String name) {
        ResultSet rs;
        int mazeID;
        try {
            getMazeID.setString(1, name);
            rs = getMazeID.executeQuery();
            rs.next();
            mazeID = rs.getInt("id");
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return mazeID;
    }

    /**
     * Return values from a maze in the database
     *
     * @param id {int} id of the table to find
     * @return {ResultSet} Maze data
     */
    public Maze getMaze(int id) {
        Maze maze = new Maze();
        ResultSet rs;
        try {
            loadMaze.setInt(1, id);
            rs = loadMaze.executeQuery();
            rs.next();
            maze.setId(rs.getInt("id"));
            maze.setAuthor(rs.getString("author"));
            maze.setName(rs.getString("name"));
            maze.setHeight(rs.getInt("height"));
            maze.setWidth(rs.getInt("width"));
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return maze;
    }

    /**
     * List all mazes in the table, and their attributes
     *
     * @return {ResultSet} maze list
     */
    public Set<String> getMazeList() {
        Set<String> mazes = new TreeSet<>();
        ResultSet rs;
        try {
            rs = listMazes.executeQuery();
            while (rs.next()) {
                mazes.add(rs.getString("name"));
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return mazes;
    }

    /**
     * @see DBUtils.mazeDataSource #getTable()
     */
    public DefaultTableModel getTable() {
        DefaultTableModel table = new DefaultTableModel(new String[]{"ID", "Author", "Name"}, 0);
        ResultSet rs;
        try {
            rs = tableMaze.executeQuery();
            while (rs.next()) {
                int id = rs.getInt("id");
                String author = rs.getString("author");
                String name = rs.getString("name");
                table.addRow(new Object[]{id, author, name});
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return table;
    }

    /**
     * @see DBUtils.mazeDataSource #getTablewithDate()
     */
    public DefaultTableModel getTablewithDate() {
        DefaultTableModel table = new DefaultTableModel(new String[]{"ID", "Author", "Name", "Created Date", "Modified Date"}, 0);
        ResultSet rs;
        try {
            rs = tableMaze.executeQuery();
            while (rs.next()) {
                int id = rs.getInt("id");
                String author = rs.getString("author");
                String name = rs.getString("name");
                String created = rs.getString("created");
                String lastUpdate = rs.getString("lastUpdate");
                table.addRow(new Object[]{id, author, name, created, lastUpdate});
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return table;
    }

    /**
     * @see DBUtils.mazeDataSource #searchTable()
     */
    public DefaultTableModel searchTable(String maze_name) {
        DefaultTableModel table = new DefaultTableModel(new String[]{"ID", "Author", "Name"}, 0);
        ResultSet rs;
        try {
            searchMaze.setString(1, "%" + maze_name + "%");
            rs = searchMaze.executeQuery();
            while (rs.next()) {
                int id = rs.getInt("id");
                String author = rs.getString("author");
                String name = rs.getString("name");
                table.addRow(new Object[]{id, author, name});
                //table = name;
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return table;
    }

    /**
     * @see DBUtils.mazeDataSource #getMazeCellGrid(int maze_id)
     */
    public Maze getMazeObject(int maze_id) {
        Maze maze = null;
        ObjectInputStream ois;
        ResultSet rs;
        try {
            loadMaze.setInt(1, maze_id);
            rs = loadMaze.executeQuery();
            rs.next();
            byte[] mazeBytes = rs.getBytes("mazeData");
            ByteArrayInputStream bis = new ByteArrayInputStream(mazeBytes);
            ois = new ObjectInputStream(bis);
            maze = (Maze) ois.readObject();
            maze.setId(maze_id); // Mazes only have IDs when read from the database
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        return maze;
    }

    /**
     * Updates the SQL database entry `id` with the data in `maze` and the new timestamp.
     *
     * @param id   The database ID of the maze
     * @param maze The maze object
     */
    public void UpdateMaze(int id, Maze maze) {
        try {
            maze.setLastEditTime(); // Update the last edit time to be now
        } catch (Exception e) {
            e.printStackTrace();
        }
        try {
            updateMaze.setBytes(1, maze.getOutputStream());
            updateMaze.setTimestamp(2, java.sql.Timestamp.valueOf(maze.getCreateTime()));
            updateMaze.setTimestamp(3, java.sql.Timestamp.valueOf(maze.getLastEditTime()));
            updateMaze.setInt(4, id);
            updateMaze.executeUpdate();
        } catch (SQLException | IOException e) {
            throw new RuntimeException(e);
        }
    }


}
