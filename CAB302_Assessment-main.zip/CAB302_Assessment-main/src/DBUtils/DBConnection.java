package DBUtils;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

/**
 * Class to handle generic database connections using details in the db.props file.
 */
public class DBConnection {

    private static Connection instance = null;

    public DBConnection() {

    }

    /**
     * Instantiates a connection to a MySQL/MariaDB server specified in the db.props file.
     */
    public static void connectDB() {
        String fileLocation;
        try {
            if (System.getProperty("os.name").contains("Windows")) {
                fileLocation = System.getProperty("user.dir") + "\\src\\DBUtils\\db.props";
            } else {
                fileLocation = System.getProperty("user.dir") + "/src/DBUtils/db.props";
            }
            FileInputStream in = new FileInputStream(fileLocation);
            Properties props = new Properties();
            props.load(in);
            in.close();
            String url = props.getProperty("jdbc.url");
            String username = props.getProperty("jdbc.username");
            String password = props.getProperty("jdbc.password");
            String schema = props.getProperty("jdbc.schema");

            instance = DriverManager.getConnection(url + "/" + schema, username,
                    password);
        } catch (IOException | SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * Get the current DB instance. If none exists, create one.
     *
     * @return {Connection} Database instance
     */
    public static Connection getInstance() {
        if (instance == null) {
            connectDB();
        }
        return instance;
    }
}
