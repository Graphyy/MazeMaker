package GUI;

import javax.swing.*;
import java.awt.event.ActionEvent;

/**
 * Interface to handle the management of windows in the program
 * @author Elliott McGrath (n9701958)
 */
public interface windows {
    /**
     * Create a new JFrame window
     * @return {JFrame} window
     */
    JFrame createWindow();

    /**
     * Sets up the basic properties of the JFrame
     * and calls populateWindow() to add lightweight
     * elements to that JFrame
     * @param window The JFrame we are setting up
     */
    void setupWindow(JFrame window);

    /**
     * Creates widgets that will be added to the JFrame
     * This method may create the widgets directly or call
     * other methods that create them.
     * @param window The JFrame we are adding elements to
     */
    void populateWindow(JFrame window);

    /** Returns the JFrame of the class that implements it
     */
    JFrame returnJFrame();

    /**
     * Close a JFrame window
     */
    void killJFrame();

    /**
     * Event handler method to be implemented by
     * various different classes
     * @param e an ActionEvent object passed by the event listener
     */
    void actionPerformed(ActionEvent e);
}
