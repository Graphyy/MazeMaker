package GUI;

import DBUtils.mazeDataBase;
import GUI.Graphics.DrawPanel;
import GUI.Graphics.MarkerGrid;
import MazeUtils.MazeDataTypes.*;
import MazeUtils.MazeSolver;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.sql.SQLException;
import java.util.List;

/**
 * Creates the GUI interface for editing mazes
 * @author Elliott McGrath (n9701958)
 */
public class MazeEdit extends MazeGUI implements Runnable {

    private static final int WINDOW_WIDTH = 650;
    private static final int WINDOW_HEIGHT = 700;
    private static final int CONTROL_PANEL_W = 200;
    private static final int CONTROL_PANEL_H = 650;

    CellGrid cellGrid;
    DrawPanel drawPanel;
    MarkerGrid markerGrid;
    Maze maze;
    JCheckBox solveCheckbox;
    JCheckBox entryExit;
    float percentage;

    private int markerXPos, markerYPos;
    Cell start, end;

    /**
     * Method used when invoking a new instance of MazeEdit
     * that ensures threading is properly handled
     */
    @Override
    public void run() {
        // initialise programWindow with a new JFrame for the mazeEdit dialog
        programWindow = createWindow();

        // Set the parameters of our JFrame for the MazeEdit dialog and call the method to populate the window
        setupWindow(programWindow);
    }

    /**
     * Load a maze into the mazeEdit window for modification
     * @param maze The maze to be loaded
     * @return a Runnable method used to load the maze in a thread-safe manner
     */
    public Runnable loadMaze(Maze maze) {
        this.maze = maze;
        int gridX = maze.getWidth();
        int gridY = maze.getHeight();
        int cellSize = maze.getCellSize();

        cellGrid = maze.getCellGrid();
        String[] start_coords = cellGrid.entryCell;
        String[] end_coords = cellGrid.exitCell;
        start = cellGrid.getCell(Integer.parseInt(start_coords[0]), Integer.parseInt(start_coords[1]));
        end = cellGrid.getCell(Integer.parseInt(end_coords[0]), Integer.parseInt(end_coords[1]));

        initialiseGUIObjects(gridX, gridY, cellSize);
        return this;
    }

    /**
     * Create a markerGrid and DrawPanel for the maze editing window
     * @param gridX Horizontal size of the maze in number of cells
     * @param gridY Vertical size of the maze in number of cells
     * @param cellSize Size of the cells in the maze in pixels
     */
    private void initialiseGUIObjects(int gridX, int gridY, int cellSize) {
        // Create a 2-dimensional array of marker objects that mirrors the dimensions of the maze
        markerGrid = setupMarkerGrid(gridX, gridY, cellSize);

        // Create a draw panel to render 2d graphics
        drawPanel = setupDrawPanel(gridX, gridY, cellSize);
    }

    /**
     * Helper method called by initialiseGUIObjects to create and configure a DrawPanel for maze editing
     * @param gridX Horizontal size of the maze in number of cells
     * @param gridY Vertical size of the maze in number of cells
     * @param cellSize  Size of the cells in the maze in pixels
     * @return A drawpanel configured to display the maze
     */
    private DrawPanel setupDrawPanel(int gridX, int gridY, int cellSize) {
        // Create a draw panel to render 2d graphics
        DrawPanel aDrawPanel = new DrawPanel(markerGrid, maze.getCellGrid(), gridX, gridY, cellSize, maze.getLogo());
        aDrawPanel.setPreferredSize(new Dimension((gridX) * cellSize, (gridY) * cellSize));
        aDrawPanel.addKeyListener(new KeyListen());
        aDrawPanel.addMouseListener(new MouseListen());
        aDrawPanel.setFocusable(true);
        return aDrawPanel;
    }

    /**
     * Specific implementation of createWindow that creates a JFrame
     * to contain the GUI elements, and sets its parameters.
     * @author Elliott McGrath (n9701958)
     */
    @Override
    public JFrame createWindow() {
        JFrame window = new JFrame("Maze Maker");
        window.setVisible(true); // Make it so we can see the JFrame
        window.addWindowListener(new WindowAdapter() {  // Program will return to Landing Page if window is closed via the X
            @Override
            public void windowClosing(WindowEvent e) {
                killJFrame();
                openLandingPage();
            }
        });
        window.addWindowFocusListener(new editWindowListener());

        // Make the window appear roughly in the center of the screen
        Dimension dimension = Toolkit.getDefaultToolkit().getScreenSize();
        int x = (int) ((dimension.getWidth() - WINDOW_WIDTH) / 2 );
        int y = (int) ((dimension.getHeight() - WINDOW_HEIGHT) / 4);
        window.setLocation(x, y);

        return window;
    }

    /**
     * Method that sets up the newly created JFrame and adds elements to it
     * @author Elliott McGrath (n9701958)
     */
    @Override
    public void setupWindow(JFrame window) {
        window.setPreferredSize(new Dimension(WINDOW_WIDTH, WINDOW_HEIGHT));
        window.setMinimumSize(new Dimension(WINDOW_WIDTH, WINDOW_HEIGHT));
        window.setJMenuBar(createMenuBar()); // Set up the menu bar at the top of the screen
        populateWindow(window);
        window.pack();
    }

    /**
     * Initialise a MarkerGrid object which will be populated with Marker objects,
     * and make the marker at 1,1 visible.
     * The MarkerGrid is used to track the position of our Marker objects.
     * The Marker objects are
     * It is initialised at a size which matches the dimensions of our maze exactly.
     *
     * @param gridX    The number of square cells for the X axis of the maze
     * @param gridY    The number of square cells for the Y axis of the maze
     * @param cellSize The size of each square cell in pixels
     * @author Elliott McGrath (n9701958)
     */
    private MarkerGrid setupMarkerGrid(int gridX, int gridY, int cellSize) {
        MarkerGrid mGrid = new MarkerGrid(gridX, gridY, cellSize);  // Create the marker grid
        markerXPos = 1;
        markerYPos = 1;
        mGrid.toggleMarkerVisible(markerXPos, markerYPos);    // Initialise a marker at 1, 1 in the grid
        return mGrid;
    }


    /**
     * Creates elements for the MazeEdit window: <br/>
     * 1. Adds a JPanel to contain the other elements.<br/>
     * 2. Adds a JPanel to contain the maze editing elements.<br/>
     * 3. Adds a ScrollPane within the maze edit JPanel to hold the DrawPanel.<br/>
     * 4. Adds a DrawPanel to the ScrollPane to render our 2d graphics.<br/>
     * 5. Adds a controlPanel to contain the elements that receive user input.<br/>
     * 6. Adds interactive elements to the control panel.<br/>
     * 7. Adds all the above elements to the window.<br/>
     *
     * @param window The JFrame we are adding elements to
     */
    @Override
    public void populateWindow(JFrame window) {

        Font ital = new Font(new JLabel().getFont().getFamily(), Font.ITALIC, new JLabel().getFont().getSize());

        // Create a 'parent' JPanel to contain the other JPanels
        JPanel parentPanel = new JPanel();
        parentPanel.setLayout(new BoxLayout(parentPanel, BoxLayout.LINE_AXIS));
        parentPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 0));

        // Create a JPanel for the area where the maze is rendered
        JPanel mazePanel = new JPanel();
        mazePanel.setBorder(BorderFactory.createEmptyBorder(0, 10, 0, 0));
        mazePanel.setLayout(new GridLayout(1, 1));

        // Set up a JScrollPane, add DrawPanel to it
        JScrollPane scrollPane = new JScrollPane(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        scrollPane.getHorizontalScrollBar().addAdjustmentListener(new scrollBarListener());
        scrollPane.getVerticalScrollBar().addAdjustmentListener(new scrollBarListener());

        if (drawPanel != null) {
            scrollPane.add(drawPanel);  // Insert drawPanel into the ScrollPane
            scrollPane.setViewportView(drawPanel); // Set viewport to the DrawPanel
        }

        // Create a JPanel to contain all the user-input elements
        JPanel controlsPanel = new JPanel();
        controlsPanel.setLayout(new BoxLayout(controlsPanel, BoxLayout.PAGE_AXIS));
        controlsPanel.setMaximumSize(new Dimension(CONTROL_PANEL_W, CONTROL_PANEL_H));
        controlsPanel.setMinimumSize(new Dimension(CONTROL_PANEL_W, CONTROL_PANEL_H));

        // Create a save, load and delete buttons for the database
        JButton SaveToDB = addButton("Save to Database", "Save to DB");
        JButton LoadFromDB = addButton("Load from Database", "Load from DB");
        JButton DeleteFromDB = addButton("Delete Maze", "Delete from DB");

        // Create a container for the three database Buttons
        JPanel databaseButtonsPanel = new JPanel();
        databaseButtonsPanel.setMaximumSize(new Dimension(CONTROL_PANEL_W, 90));
        databaseButtonsPanel.setLayout(new GridLayout(3, 1, 0, 5));
        databaseButtonsPanel.add(SaveToDB);
        databaseButtonsPanel.add(LoadFromDB);
        databaseButtonsPanel.add(DeleteFromDB);


        // Create a JPanel for the directional controls
        JPanel directionLabelPanel = addLabelPanel("Movement controls:");
        directionLabelPanel.setMaximumSize(new Dimension(CONTROL_PANEL_W, 25));
        JPanel directionPanel = new JPanel(new BorderLayout(5, 5));
        directionPanel.setMaximumSize(new Dimension(CONTROL_PANEL_W, 90));

        // Create some buttons for the control panel and add them to controlPanel
        JButton MarkerUp = addButton("Up", "Up");
        JButton MarkerDown = addButton("Down", "Down");
        JButton MarkerLeft = addButton("Left", "Left");
        JButton MarkerRight = addButton("Right", "Right");

        directionPanel.add(MarkerUp, BorderLayout.NORTH);
        directionPanel.add(MarkerDown, BorderLayout.SOUTH);
        directionPanel.add(MarkerLeft, BorderLayout.WEST);
        directionPanel.add(MarkerRight, BorderLayout.EAST);

        // Create a JPanel for the wall controls
        JPanel wallLabelPanel = addLabelPanel("Toggle wall:");
        wallLabelPanel.setMaximumSize(new Dimension(CONTROL_PANEL_W, 25));
        JPanel wallPanel = new JPanel(new BorderLayout(8, 5));
        wallPanel.setMaximumSize(new Dimension(CONTROL_PANEL_W, 90));

        //wallPanel.setBorder(BorderFactory.createLineBorder(Color.MAGENTA));

        JButton wallUp = addButton("Up", "Up Wall");
        JButton wallDown = addButton("Down", "Down Wall");
        JButton wallLeft = addButton("Left", "Left Wall");
        JButton wallRight = addButton("Right", "Right Wall");
        wallPanel.add(wallUp, BorderLayout.NORTH);
        wallPanel.add(wallDown, BorderLayout.SOUTH);
        wallPanel.add(wallLeft, BorderLayout.WEST);
        wallPanel.add(wallRight, BorderLayout.EAST);

        //Create a JPanel for start and end button controls
        JPanel startendLabelPanel = addLabelPanel("Set Maze Entry and Exit:");
        startendLabelPanel.setLayout(new GridLayout(1,1));
        startendLabelPanel.setMaximumSize(new Dimension(CONTROL_PANEL_W, 25));
        JPanel startendPanel = new JPanel(new GridLayout(1,2, 5, 0));
        startendPanel.setMaximumSize((new Dimension(CONTROL_PANEL_W, 25)));
        JButton start = addButton("Entry", "Start Coord");
        JButton end = addButton("Exit", "End Coord");
        startendPanel.add(start);
        startendPanel.add(end);

        // Create an area for some checkboxes - Legend toggle & Solve
        JPanel solverLabelPanel = new JPanel();
        solverLabelPanel.setLayout(new GridLayout(1, 1, 0, 0));
        JLabel solverLabel = new JLabel("Solver Tools:");
        solverLabelPanel.setMaximumSize(new Dimension(CONTROL_PANEL_W, 10));
        solverLabelPanel.add(solverLabel);

        JPanel checkBoxPanel1 = new JPanel();
        checkBoxPanel1.setLayout(new GridLayout(1, 2, 0, 0));
        JLabel checkBoxPanel1Label = new JLabel("Show numbers:");
        checkBoxPanel1Label.setFont(ital);
        checkBoxPanel1.add(checkBoxPanel1Label);

        JCheckBox legendCheckbox = new JCheckBox("Legend");
        legendCheckbox.setSelected(true);
        legendCheckbox.addActionListener(new ActionListen());
        legendCheckbox.setActionCommand("LEGEND");
        checkBoxPanel1.add(legendCheckbox);

        JPanel checkBoxPanel2 = new JPanel();
        checkBoxPanel2.setLayout(new GridLayout(1, 2, 0, 0));
        JLabel checkBoxPanel2Label = new JLabel("Show Entry/Exit:");
        checkBoxPanel2Label.setFont(ital);
        checkBoxPanel2.add(checkBoxPanel2Label);
        entryExit = addListenBox("Entry/Exit", false);
        checkBoxPanel2.add(entryExit);

        JPanel solverPanel1 = new JPanel();
        solverPanel1.setLayout(new GridLayout(1, 2, 0, 0));
        JLabel solverPanel1Label = new JLabel("Show Solution:");
        solverPanel1Label.setFont(ital);
        solverPanel1.add(solverPanel1Label);
        solveCheckbox =  addListenBox("SOLVE", false);
        solverPanel1.add(solveCheckbox);

        JPanel solverPanel2 = new JPanel();
        solverPanel2.setLayout(new GridLayout(1,1,0,0));
        JButton percentageButton = addButton("Show Solver percentage", "Percentage");
        solverPanel2.add(percentageButton);

        JPanel parentSolverPanel = new JPanel();
        parentSolverPanel.setLayout(new GridLayout(4, 1, 0, 2));
        parentSolverPanel.setMaximumSize(new Dimension(CONTROL_PANEL_W, 100));
        parentSolverPanel.add(checkBoxPanel1);
        parentSolverPanel.add(checkBoxPanel2);
        parentSolverPanel.add(solverPanel1);
        parentSolverPanel.add(solverPanel2);

        JPanel placeLogoPanel = new JPanel();
        placeLogoPanel.setLayout(new GridLayout(1,1));
        JButton placeLogo = addButton("Place Logo", "logo");
        placeLogoPanel.add(placeLogo);

        controlsPanel.add(databaseButtonsPanel);
        controlsPanel.add(Box.createRigidArea(new Dimension(0, 10)));
        controlsPanel.add(directionLabelPanel);
        controlsPanel.add(directionPanel);
        controlsPanel.add(Box.createRigidArea(new Dimension(0, 5)));
        controlsPanel.add(wallLabelPanel);
        controlsPanel.add(wallPanel);
        controlsPanel.add(Box.createRigidArea(new Dimension(0, 15)));
        controlsPanel.add(solverLabelPanel);
        controlsPanel.add(Box.createRigidArea(new Dimension(0, 5)));
        controlsPanel.add(parentSolverPanel);
        controlsPanel.add(Box.createRigidArea(new Dimension(0, 15)));
        controlsPanel.add(startendLabelPanel);
        controlsPanel.add(Box.createRigidArea(new Dimension(0, 5)));
        controlsPanel.add(startendPanel);
        controlsPanel.add(Box.createRigidArea(new Dimension(0, 20)));
        controlsPanel.add(placeLogoPanel);








        /* Finally, add all the widgets in the correct order */
        mazePanel.add(scrollPane); // Add scrollPane into MazePanel
        parentPanel.add(controlsPanel);
        parentPanel.add(mazePanel); // Add mazePanel into ParentPanel
        parentPanel.add(Box.createRigidArea(new Dimension(10, 10))); // add some padding to the right side of parentWindow
        window.getContentPane().add(parentPanel); //add ParentPanel to the JFrame
    }

    /**
     * A helper method to quickly add JButton objects to a JPanel
     *
     * @param text The text to be shown on the menu item, which is also its ActionCommand string
     * @return A JButton object with a pre-defined actionListener and
     * @author Elliott McGrath (n9701958)
     */
    private JButton addButton(String text, String command) {
        JButton button = new JButton(text);
        button.addActionListener(new ActionListen());
        button.setActionCommand(command);
        button.setMaximumSize(new Dimension(CONTROL_PANEL_W, 25));

        return button;
    }

    /**
     * A helper method to quickly add Label objects to a JPanel
     * @param text The text to be displayed by the label
     * @return A JLabel object with a flowlayout containing the specified text
     * @author Elliott McGrath (n9701958)
     */
    private JPanel addLabelPanel(String text) {
        JPanel aLabelPanel = new JPanel();
        aLabelPanel.setLayout(new FlowLayout(FlowLayout.LEFT));
        JLabel aLabel = new JLabel(text);
        aLabelPanel.add(aLabel);
        return aLabelPanel;
    }


    /**
     * A helper method to add a checkbox with an ItemStateListener attached to it.
     * @param text Text to be displayed next to the checbox
     * @param ticked True if the checkbox is ticked, false if it is blank
     * @return JCheckbox object with the specified text
     */
    private JCheckBox addListenBox(String text, @SuppressWarnings("SameParameterValue") boolean ticked) {
        JCheckBox checkbox = new JCheckBox(text);
        checkbox.setSelected(ticked);
        checkbox.addItemListener(new ItemStateListener());
        checkbox.setActionCommand(text);
        return checkbox;
    }

    /**
     * Short method to set up the menu bar items for the MazeEdit Window
     * @return A JMenuBar object that can be displayed in a JFrame
     * @author Elliott McGrath (n9701958)
     */
    private JMenuBar createMenuBar() {

        // Create the menu bar
        JMenuBar menuBar;
        menuBar = new JMenuBar();

        // Add Back Button to the menu bar
        JButton backButton = new JButton("< Back");
        backButton.setOpaque(false);
        backButton.setContentAreaFilled(false);
        backButton.setBorderPainted(false);
        backButton.addActionListener(new MazeEdit.ActionListen());
        backButton.setActionCommand("Back");
        menuBar.add(backButton);

        menuBar.add(Box.createHorizontalGlue());

        /* Create several new menu items and add them to the menu bar */
        JMenu file, edit, help;
        file = new JMenu("File");
        help = new JMenu("Help");
        menuBar.add(file);
        menuBar.add(help);

        // Add the menu items to the 'File' menu
        newMenuItem("New", file);
        newMenuItem("Open", file);
        newMenuItem("Save to DB", file);
        newMenuItem("Save As", file);
        newMenuItem("Close", file);

        // Add the menu items to the 'Help' menu
        newMenuItem("Key Controls", help);

        return menuBar;
    }

    /**
     * A helper method to quickly add JMenuItem objects to a JMenu
     *
     * @param text The text to be shown on the menu item, which is also its ActionCommand string
     * @param menu The JMenu we want to add the JMenuItem to
     * @author Elliott McGrath (n9701958)
     */
    private void newMenuItem(String text, JMenu menu) {
        JMenuItem item = new JMenuItem(text);
        item.addActionListener(new ActionListen()); // Add action listeners for the menu items and define their action commands
        item.setActionCommand(text); // Set the action listener command to be the same as its name
        menu.add(item); // add the new menu item to the menu
    }

    /**
     * Method to open the file picker dialog and allow a user to select a maze to load
     *
     * @author Elliott McGrath (n9701958)
     */
    private void openFileLoad() throws IOException, ClassNotFoundException {
        JFileChooser picker = new JFileChooser();
        int choice = picker.showOpenDialog(programWindow);
        if (choice == JFileChooser.APPROVE_OPTION) {
            File file = picker.getSelectedFile();
            FileInputStream fin = new FileInputStream(file);
            ObjectInputStream ois = new ObjectInputStream(fin);
            Maze maze = (Maze) ois.readObject();
            ois.close();
            fin.close();
            killJFrame();
            openMazeEdit(maze);
        }
    }

    /**
     * Method to allow for the saving of mazes as local files
     * @param maze The maze object to Save
     * @author Elliott McGrath (n9701958)
     */
    private void saveMaze(Maze maze) throws IOException {

        JFileChooser picker = new JFileChooser();
        String currentUsersHomeDir = System.getProperty("user.home");

        String pathname = currentUsersHomeDir + File.separator + maze.getName() + ".maze";

        picker.setSelectedFile(new File(pathname));
        picker.setCurrentDirectory(new File(currentUsersHomeDir));
        picker.setFileSelectionMode(JFileChooser.FILES_ONLY);

        int choice = picker.showSaveDialog(programWindow);
        File file = null;

        if (choice == JFileChooser.APPROVE_OPTION) {
            file = picker.getSelectedFile();
        }

        assert file != null;

        if (file.createNewFile())
            System.out.println("File created");
        else
            System.out.println("File already exists");

        FileOutputStream fos = new FileOutputStream(file);
        ObjectOutputStream oos = new ObjectOutputStream(fos);
        oos.writeObject(maze);

    }

    /**
     * Internal Class for handling mouseclick events in the window
     */
    private class MouseListen implements MouseListener {

        @Override
        public void mouseClicked(MouseEvent e) {
            if(e.getComponent() == drawPanel) {
                drawPanel.requestFocusInWindow();
            }
        }

        @Override
        public void mousePressed(MouseEvent e) {

        }

        @Override
        public void mouseReleased(MouseEvent e) {

        }

        @Override
        public void mouseEntered(MouseEvent e) {

        }

        @Override
        public void mouseExited(MouseEvent e) {

        }
    }

    /**
     * Internal class that handles inputs to the solver checkbox and entry/exit checkbox
     */
    private class ItemStateListener implements ItemListener{
        public void itemStateChanged(ItemEvent e) {
            JCheckBox anItem = (JCheckBox) e.getItem();

            String actionCommand = anItem.getActionCommand();

            if (actionCommand.equals("SOLVE")) {
                if (maze == null){
                    JOptionPane.showMessageDialog(programWindow,
                            "No maze selected!",
                            "Error",
                            JOptionPane.WARNING_MESSAGE);
                }else{
                    if (solveCheckbox.isSelected()) {
                        // Implement here
                        Graphics g = drawPanel.getGraphics();
                        if(start != null && end != null){
                            MazeSolver solveMaze = new MazeSolver(maze,cellGrid, g, start, end, cellGrid.getCellSize());
                            List<Cell> path = solveMaze.DFS();
                            percentage = solveMaze.PercentageCells();
                            if(path != null){
                                solveMaze.drawPath(path);
                            }} else {
                            Pop();
                        }
                    } else {
                        drawPanel.repaint();
                    }
                }
            } else if (actionCommand.equals("Entry/Exit")) {
                if (maze == null){
                    JOptionPane.showMessageDialog(programWindow,
                            "No maze selected!",
                            "Error",
                            JOptionPane.WARNING_MESSAGE);
                }
                else{
                    if (e.getStateChange() == ItemEvent.SELECTED) {
                        Graphics g = drawPanel.getGraphics();
                        if(start != null && end != null){
                            CellGrid cellGrid = maze.getCellGrid();
                            String[] start_coords = cellGrid.entryCell;
                            String[] end_coords = cellGrid.exitCell;
                            Cell start = cellGrid.getCell(Integer.parseInt(start_coords[0]),Integer.parseInt(start_coords[1]));
                            Cell end = cellGrid.getCell(Integer.parseInt(end_coords[0]),Integer.parseInt(end_coords[1]));
                            int[] intstart_coords = start.getCoords();
                            int[] intend_coords = end.getCoords();

                            //draw entry
                            g.setColor(Color.GREEN);
                            g.drawOval(intstart_coords[0]+3,intstart_coords[1]+3,maze.getCellSize()-6,maze.getCellSize()-6);
                            g.fillOval(intstart_coords[0]+3,intstart_coords[1]+3,maze.getCellSize()-6,maze.getCellSize()-6);

                            //draw exit
                            g.setColor(Color.RED);
                            g.drawOval(intend_coords[0]+3,intend_coords[1]+3,maze.getCellSize()-6,maze.getCellSize()-6);
                            g.fillOval(intend_coords[0]+3,intend_coords[1]+3,maze.getCellSize()-6,maze.getCellSize()-6);
                        }
                        else{
                            Pop();
                        }
                    }
                    else{
                        drawPanel.repaint();
                    }
                }


            }
        }
    }

    /**
     * Internal class that implements ActionListener
     * So that the outer class can use its features.
     * @author Elliott McGrath (n9701958)
     */
    private class ActionListen implements ActionListener {
        /**
         * Action event handler to work with interactive UI elements
         * @param e ActionEvent object which contains information such as the ActionCommand
         */
        @Override
        public void actionPerformed(ActionEvent e) {
            String command = e.getActionCommand();
            switch(command) {
                case "Back":
                    killJFrame();
                    openLandingPage();
                    break;
                case "New":
                    killJFrame();
                    openMazeCreate();
                    break;
                case "Open":
                    try {
                        openFileLoad();
                    } catch (IOException | ClassNotFoundException ex) {
                        ex.printStackTrace();
                    }
                    break;
                case "Delete from DB":
                    mazeDataBase mazeDataB = new mazeDataBase();
                    try{
                        if (maze == null){
                            JOptionPane.showMessageDialog(programWindow,
                                    "No maze selected!",
                                    "Error",
                                    JOptionPane.WARNING_MESSAGE);
                            break;
                        }
                        int input = JOptionPane.showConfirmDialog(programWindow,
                                "Are you sure you want to delete this maze?", "Confirm Delete",
                                JOptionPane.YES_NO_OPTION, JOptionPane.ERROR_MESSAGE);
                        if (input == 0){ 
                            Boolean deleted = mazeDataB.deleteMaze(mazeDataB.getMazeId(maze.getName()));
                            if(deleted){
                                JOptionPane.showMessageDialog(programWindow,
                                        "Maze successfully deleted!",
                                        "Edit Maze",
                                        JOptionPane.INFORMATION_MESSAGE);
                                killJFrame();
                                openLandingPage();
                            }
                        }
                    } catch (NullPointerException ex) {
                        JOptionPane.showMessageDialog(programWindow,
                                "No maze selected!",
                                "Error",
                                JOptionPane.WARNING_MESSAGE);
                    }
                    break;

                case "Save to DB":
                    mazeDataBase mazeDB = new mazeDataBase();
                    if (maze == null){
                        JOptionPane.showMessageDialog(programWindow,
                                "No maze selected!",
                                "Error",
                                JOptionPane.WARNING_MESSAGE);
                        break;
                    }
                    maze.setCellGrid(cellGrid);
                    maze.setLastEditTime(); // Update the edit time to last save
                    try {
                        if (maze.getId() > 0) {
                            mazeDB.UpdateMaze(maze.getId(), maze);
                        } else {
                            mazeDB.createMaze(maze);
                        }
                        JOptionPane.showMessageDialog(programWindow,
                                "Maze successfully saved!",
                                "Edit Maze",
                                JOptionPane.INFORMATION_MESSAGE);
                        killJFrame();
                        openLandingPage();
                    } catch (SQLException | NullPointerException ex) {
                        JOptionPane.showMessageDialog(programWindow,
                                "No maze selected!",
                                "Error",
                                JOptionPane.WARNING_MESSAGE);
                    } catch (IOException ex) {
                        ex.printStackTrace();
                    }
                    break;
                case "Save As":
                    if (maze == null){
                        JOptionPane.showMessageDialog(programWindow,
                                "No maze selected!",
                                "Error",
                                JOptionPane.WARNING_MESSAGE);
                        break;
                    }
                    maze.setLastEditTime(); // Update the edit time to last save
                    try {
                        if (maze == null){
                            JOptionPane.showMessageDialog(programWindow,
                                    "No maze selected!",
                                    "Error",
                                    JOptionPane.WARNING_MESSAGE);
                            break;
                        }
                        saveMaze(maze);
                    } catch (IOException ex) {
                        ex.printStackTrace();
                    }
                    break;
                case "Close":
                    killJFrame();
                    openLandingPage();
                    break;
                case "Start Coord":
                    if (maze == null){
                        JOptionPane.showMessageDialog(programWindow,
                                "No maze selected!",
                                "Error",
                                JOptionPane.WARNING_MESSAGE);
                        break;
                    }
                    start = cellGrid.getCell(markerXPos,markerYPos);
                    int[] start_coords = start.getCoords();
                    cellGrid.setEntryExitCell(start_coords[0]/ maze.getCellSize(),start_coords[1]/ maze.getCellSize(),"Entry");
                    Graphics g = drawPanel.getGraphics();
                    g.setColor(Color.ORANGE);
                    g.drawOval(start_coords[0],start_coords[1],maze.getCellSize(),maze.getCellSize());
                    g.fillOval(start_coords[0],start_coords[1],maze.getCellSize(),maze.getCellSize());
                    break;
                case "End Coord" :
                    if (maze == null){
                        JOptionPane.showMessageDialog(programWindow,
                                "No maze selected!",
                                "Error",
                                JOptionPane.WARNING_MESSAGE);
                        break;
                    }
                    end = cellGrid.getCell(markerXPos,markerYPos);
                    int[] end_coords = end.getCoords();
                    cellGrid.setEntryExitCell(end_coords[0]/ maze.getCellSize(),end_coords[1]/ maze.getCellSize(),"Exit");
                    Graphics graphics = drawPanel.getGraphics();
                    graphics.setColor(Color.DARK_GRAY);
                    graphics.drawOval(end_coords[0],end_coords[1],maze.getCellSize(),maze.getCellSize());
                    graphics.fillOval(end_coords[0],end_coords[1],maze.getCellSize(),maze.getCellSize());
                    break;
                case "Up":
                    if (maze == null){
                        JOptionPane.showMessageDialog(programWindow,
                                "No maze selected!",
                                "Error",
                                JOptionPane.WARNING_MESSAGE);
                        break;
                    }
                    moveMarker("UP");
                    toggleSolveCheckBoxes();
                    break;
                case "Down":
                    if (maze == null){
                        JOptionPane.showMessageDialog(programWindow,
                                "No maze selected!",
                                "Error",
                                JOptionPane.WARNING_MESSAGE);
                        break;
                    }
                    moveMarker("DOWN");
                    toggleSolveCheckBoxes();
                    break;
                case "Left":
                    if (maze == null){
                        JOptionPane.showMessageDialog(programWindow,
                                "No maze selected!",
                                "Error",
                                JOptionPane.WARNING_MESSAGE);
                        break;
                    }
                    moveMarker("LEFT");
                    toggleSolveCheckBoxes();
                    break;
                case "Right":
                    if (maze == null){
                        JOptionPane.showMessageDialog(programWindow,
                                "No maze selected!",
                                "Error",
                                JOptionPane.WARNING_MESSAGE);
                        break;
                    }
                    moveMarker("RIGHT");
                    toggleSolveCheckBoxes();
                    break;
                case "Percentage":
                    if (maze == null){
                        JOptionPane.showMessageDialog(programWindow,
                                "No maze selected!",
                                "Error",
                                JOptionPane.WARNING_MESSAGE);
                        break;
                    }
                    if(solveCheckbox.isSelected()){

                        PopVisitedCell();
                    }
                    else {
                        PopSolver();
                    }
                    break;
                case "LEGEND":
                    if (maze == null){
                        JOptionPane.showMessageDialog(programWindow,
                                "No maze selected!",
                                "Error",
                                JOptionPane.WARNING_MESSAGE);
                        break;
                    }
                    drawPanel.drawLegend = !drawPanel.drawLegend;
                    drawPanel.repaint();
                    toggleSolveCheckBoxes();
                    break;
                case "Up Wall":
                    if (maze == null){
                        JOptionPane.showMessageDialog(programWindow,
                                "No maze selected!",
                                "Error",
                                JOptionPane.WARNING_MESSAGE);
                        break;
                    }
                    cellGrid.toggleWall(markerXPos, markerYPos, cellGrid, "UP");
                    drawPanel.repaint();
                    toggleSolveCheckBoxes();
                    break;
                case "Down Wall":
                    if (maze == null){
                        JOptionPane.showMessageDialog(programWindow,
                                "No maze selected!",
                                "Error",
                                JOptionPane.WARNING_MESSAGE);
                        break;
                    }
                    cellGrid.toggleWall(markerXPos, markerYPos, cellGrid, "DOWN");
                    drawPanel.repaint();
                    toggleSolveCheckBoxes();
                    break;
                case "Left Wall":
                    if (maze == null){
                        JOptionPane.showMessageDialog(programWindow,
                                "No maze selected!",
                                "Error",
                                JOptionPane.WARNING_MESSAGE);
                        break;
                    }
                    cellGrid.toggleWall(markerXPos, markerYPos, cellGrid, "LEFT");
                    drawPanel.repaint();
                    toggleSolveCheckBoxes();
                    break;
                case "Right Wall":
                    if (maze == null){
                        JOptionPane.showMessageDialog(programWindow,
                                "No maze selected!",
                                "Error",
                                JOptionPane.WARNING_MESSAGE);
                        break;
                    }
                    cellGrid.toggleWall(markerXPos, markerYPos, cellGrid, "RIGHT");
                    drawPanel.repaint();
                    toggleSolveCheckBoxes();
                    break;
                case "Key Controls":
                    JOptionPane help = new JOptionPane();
                    final String helpMessage = "<html><div style=\"padding-right:20px;\">To move the marker around the maze, click on the maze and then use the W, S, A, D keys.<br />" +
                            "To adjust the viewing position of the maze horizontally / vertically, use the directional arrow keys.</div></html>";
                    JOptionPane.showMessageDialog(help, helpMessage,"Keyboard Controls", JOptionPane.INFORMATION_MESSAGE);
                    break;
                case "Load from DB":
                    killJFrame();
                    openMazeDBBrowser();
                    break;
                case "logo":
                    if (maze == null){
                        JOptionPane.showMessageDialog(programWindow,
                                "No maze selected!",
                                "Error",
                                JOptionPane.WARNING_MESSAGE);
                        break;
                    }

                    int xy = 0;
                    Logo logo = maze.getLogo();
                    try {
                        xy = logo.getSize();
                    } catch(NullPointerException ex) {
                        JFileChooser fileChooser = new JFileChooser();
                        int choice = fileChooser.showOpenDialog(programWindow);
                        if(choice == JFileChooser.APPROVE_OPTION) {
                            File file = fileChooser.getSelectedFile();
                            try {
                                FileInputStream fin = new FileInputStream(file);
                                if (logo == null) {
                                    logo = new Logo(ImageIO.read(fin), 2);
                                    maze.setLogo(logo);
                                    drawPanel.setLogo(logo);
                                } else {
                                    logo.setBufferedImg(ImageIO.read(fin));
                                }
                            } catch (IOException exp) {
                                exp.printStackTrace();
                            }

                        }
                    }


                    cellGrid.setLogoCoords(xy, markerXPos, markerYPos);
                    drawPanel.drawLogo(drawPanel.getGraphics(), cellGrid);
                    drawPanel.repaint();

                    break;
                default:
                    break;
            }
        }
    }

    private void toggleSolveCheckBoxes() {
        solveCheckbox.setSelected(false);
        entryExit.setSelected(false);
    }

    /**
     * Method allowing the user to move the blue marker around the edit screen
     * @author Elliott McGrath (n9701958)
     * @param direction A string representing the direction the user wishes to move in
     */
    private void moveMarker(String direction) {
        markerGrid.toggleMarkerVisible(markerXPos,markerYPos);
        switch (direction) {
            case "UP":
                if(markerYPos == 1) {
                    markerYPos = markerGrid.getGridY() - 2;
                } else {
                    markerYPos--;
                }
                break;
            case "DOWN":
                if(markerYPos == markerGrid.getGridY() - 2) {
                    markerYPos = 1;
                } else {
                    markerYPos++;
                }
                break;
            case "LEFT":
                if(markerXPos == 1) {
                    markerXPos = markerGrid.getGridX()  - 2;
                } else {
                    markerXPos--;
                }
                break;
            case "RIGHT":
                if(markerXPos == markerGrid.getGridX() - 2) {
                    markerXPos = 1;
                } else {
                    markerXPos++;
                }
                break;
            default:
                break;
        }
        markerGrid.toggleMarkerVisible(markerXPos,markerYPos);
        drawPanel.repaint();
        toggleSolveCheckBoxes();
    }

    /**
     * Internal class to handle WASD inputs from keyboard
     * which are used to move the marker around the edit screen
     */
    private class KeyListen implements KeyListener {

        @Override
        public void keyTyped(KeyEvent e) {

        }

        @Override
        public void keyPressed(KeyEvent e) {
            switch (e.getKeyCode()) {
                case KeyEvent.VK_W -> {
                    moveMarker("UP");
                    toggleSolveCheckBoxes();
                }
                case KeyEvent.VK_S -> {
                    moveMarker("DOWN");
                    toggleSolveCheckBoxes();
                }
                case KeyEvent.VK_A -> {
                    moveMarker("LEFT");
                    toggleSolveCheckBoxes();
                }
                case KeyEvent.VK_D -> {
                    moveMarker("RIGHT");
                    toggleSolveCheckBoxes();
                }
                default -> {
                }
            }
        }

        @Override
        public void keyReleased(KeyEvent e) {

        }
    }



    /**
     * Internal class that implements windowFocusListener
     * So that the outer class can use its features.
     * @author Elliott McGrath (n9701958)
     */
    private class editWindowListener implements WindowFocusListener {

        @Override
        public void windowGainedFocus(WindowEvent e) {
            if (drawPanel != null) {
                drawPanel.repaint();
                toggleSolveCheckBoxes();
            }
        }

        @Override
        public void windowLostFocus(WindowEvent e) {
            toggleSolveCheckBoxes();
        }


    }

    /**
     * Internal class that implements AdjustmentListener
     * So that movements of the scroll bars are registered by the program
     * @author Elliott McGrath (n9701958)
     */
    private class scrollBarListener implements AdjustmentListener  {

        @Override
        public void adjustmentValueChanged(AdjustmentEvent e) {
            toggleSolveCheckBoxes();
        }
    }

    /**
     * Method to display a dialog box when maze cannot be solved
     */
    private void Pop(){
        JFrame jFrame = new JFrame();
        JOptionPane.showMessageDialog(jFrame,"Please select Entry and Exit");
    }

    private void PopSolver(){
        JFrame jFrame = new JFrame();
        JOptionPane.showMessageDialog(jFrame,"Solver is not selected");
    }

    public void PopVisitedCell(){
        JFrame jFrame = new JFrame();
        JOptionPane.showMessageDialog(jFrame,percentage +"% of cells in the maze that are reached by an optimal solution of the maze.");
    }

}
