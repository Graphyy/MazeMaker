package GUI;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * The page the user arrives at after closing the splash screen / starting dialog box.
 * Provides choices to create, edit, export and browse mazes
 */
public class GUILandingPage extends MazeGUI implements windows, Runnable {

    final static int WINDOW_WIDTH = 300;
    final static int WINDOW_HEIGHT = 260;
    final static int MAX_BUTTON_WIDTH = 100;
    final static int MAX_BUTTON_HEIGHT = 60;
    final static int INTERNAL_PADDING = 8;
    final static int EXTERNAL_PADDING = 10;
    final static int LEFT_BORDER = 90;


    /**
     * Method used when invoking a new instance of MazeEdit
     * that ensures threading is properly handled
     */
    @Override
    public void run() {
        programWindow = createWindow();
        setupWindow(programWindow);
    }

    /**
     * Create the window for the landing page and positions it on screen
     * @author Elliott McGrath (n9701958)
     * @return window - The JFrame created by this method
     */
    @Override
    public JFrame createWindow() {
        JFrame window = new JFrame("Maze Maker");
        window.setVisible(true); // Make it so we can see the JFrame
        window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Program will exit if window is closed via the X

        // Make the landing page appear in the middle of the screen
        Dimension dimension = Toolkit.getDefaultToolkit().getScreenSize();
        int x = (int) ((dimension.getWidth() - WINDOW_WIDTH) / 2);
        int y = (int) ((dimension.getHeight() - WINDOW_HEIGHT) / 2);
        window.setLocation(x, y);

        return window;
    }

    /**
     * Set up the landing page window
     * @param window The window on which to project a landing page
     * @author Elliot McGrath
     */
    @Override
    public void setupWindow(JFrame window) {
        window.setPreferredSize(new Dimension(WINDOW_WIDTH, WINDOW_HEIGHT)); // Specify our preferred size for the window
        window.setResizable(false); // Make it so user cannot drag window to expand it
        window.setLayout(new FlowLayout(FlowLayout.LEFT));
        populateWindow(window);
        window.pack();
    }

    /**
     * Crate elements for the landing page,
     * most importantly buttons that provide an interface for the user to:
     * 1. Create a new Maze
     * 2. Edit a maze; and
     * 3. Browse the maze database
     * @author Elliott McGrath (n9701958)
     */
    @Override
    public void populateWindow(JFrame window) {

        // Create the text label, align it, and add it to the landing page
        JLabel optionsLabel = new JLabel("Select an option below to begin:");
        optionsLabel.setFont(new Font(optionsLabel.getFont().getFamily(), Font.ITALIC|Font.BOLD, 14));
        optionsLabel.setBorder(BorderFactory.createEmptyBorder(INTERNAL_PADDING,EXTERNAL_PADDING,INTERNAL_PADDING,EXTERNAL_PADDING));
        window.getContentPane().add(optionsLabel);

        // Add a JPanel to the Frame using a BoxLayout for the buttons to be aligned within
        JPanel landingPageElements = new JPanel();
        landingPageElements.setLayout(new BoxLayout(landingPageElements, BoxLayout.PAGE_AXIS));
        landingPageElements.setBorder(BorderFactory.createEmptyBorder(0, LEFT_BORDER,INTERNAL_PADDING,0));
        window.getContentPane().add(landingPageElements);

        // Add buttons to the JPanel landingPageElements
        //JButton newMaze, editMaze, exportMaze, browseData;
        addButton("New Maze", landingPageElements, "New");
        addButton("Edit Maze", landingPageElements, "Edit");
        addButton("<html><div style=\"text-align:center;\">" +
                "Export<br/>Maze",
                landingPageElements, "Export");

        addButton("<html><div style=\"text-align:center;\">" +
                "Browse<br/>Database" +
                "</div></html>", landingPageElements, "Browse");
    }


    /**
     * Method to add buttons with a specified String to the given container
     * @author Elliott McGrath (n9701958)
     */
    private void addButton(String message, Container container, String action) {
        JButton button = new JButton(message);
        button.setAlignmentX(Container.CENTER_ALIGNMENT);
        container.add(button);
        container.add(Box.createRigidArea(new Dimension(0, INTERNAL_PADDING)));
        button.setMaximumSize(new Dimension(MAX_BUTTON_WIDTH, MAX_BUTTON_HEIGHT));
        button.setMinimumSize(new Dimension(MAX_BUTTON_WIDTH, MAX_BUTTON_HEIGHT));
        button.addActionListener(new ActionListen());
        button.setActionCommand(action);
    }

    /**
     * Create a welcome dialog box with information about the program
     * @author Elliott McGrath (n9701958)
     */
    public static void showWelcomeDialog() {
        JOptionPane welcome = new JOptionPane();
        final String welcome_Message =
                "<html><div style=\"padding-left:35px;\">" +
                        "Welcome to MazeMaker! </div><br />" +
                        "<div style=\"text-align:center; padding-left:20px; padding-bottom:5px\">" +
                        "Created by: Ben Dundon, Nini Kao,<br />Jing Xuan Yew, Elliott McGrath </div></html>";
        JOptionPane.showMessageDialog(welcome, welcome_Message,"MazeMaker", JOptionPane.PLAIN_MESSAGE);
    }


    /**
     * Internal class that implements ActionListener
     * So that the outer class can use its features.
     * @author Elliott McGrath (n9701958)
     */
    private class ActionListen implements ActionListener {
        /**
         * Action event handler to work with interactive UI elements
         * @param e ActionEvent object which contains information such as the ActionCommand
         */
        @Override
        public void actionPerformed(ActionEvent e) {
            if (e.getActionCommand().equals("New")) {

                killJFrame();
                openMazeCreate();
            }

            if (e.getActionCommand().equals("Edit")) {
                killJFrame();
                openBlankMazeEdit();
            }

            if (e.getActionCommand().equals("Export")) {
                killJFrame();
                openMazeExport();
            }

            if (e.getActionCommand().equals("Browse")) {
                killJFrame();
                openMazeDBBrowser();
            }
        }
    }


}
