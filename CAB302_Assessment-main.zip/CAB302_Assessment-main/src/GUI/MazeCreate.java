//TODO: Maze difficulty

package GUI;

import MazeUtils.MazeDataTypes.*;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

/**
 * Sets up window for creating new mazes
 */
public class MazeCreate extends MazeGUI implements Runnable {

    private static final int WINDOW_WIDTH = 600;
    private static final int WINDOW_HEIGHT = 550;
    private static final int TEXTBOX_HEIGHT = 8;
    private static final int TEXTBOX_PADDING = 100;
    private static final int HEAVY_PADDING = 18;
    private static final int LIGHT_PADDING = 10;

    public TextField authorNameField, mazeTitleField, mazeWidthField, mazeHeightField;
    public JSlider mazeDifficulty, mazeCellSize;
    public Logo logo = null;

    /**
     * Method used when invoking a new instance of MazeEdit
     * that ensures threading is properly handled
     */
    @Override
    public void run() {
        programWindow = createWindow();
        setupWindow(programWindow);
    }

    /**
     * Specific implementation of createWindow that customises certain aspects of design
     * Mainly the positioning of the window on the user's screen
     * @author Elliott McGrath (n9701958)
     */
    @Override
    public JFrame createWindow () {
        JFrame window = new JFrame("Maze Maker - Create a new Maze");
        window.setVisible(true); // Make it so we can see the JFrame
        window.addWindowListener(new WindowAdapter() {  // Program will return to Landing Page if window is closed via the X
            @Override
            public void windowClosing(WindowEvent e) {
                killJFrame();
                openLandingPage();
            }
        });

        Dimension dimension = Toolkit.getDefaultToolkit().getScreenSize();
        int x = (int) ((dimension.getWidth() - WINDOW_WIDTH ) / 2 );
        int y = (int) ((dimension.getHeight() - WINDOW_HEIGHT) / 2);
        window.setLocation(x, y);

        return window;
    }

    /**
     * Set up a new window in an existing JFrame
     * @param window The JFrame we are setting up
     */
    @Override
    public void setupWindow(JFrame window) {
        window.setPreferredSize(new Dimension(WINDOW_WIDTH,WINDOW_HEIGHT));
        window.setResizable(false);
        window.setJMenuBar(createMenuBar()); // Set up the menu bar at the top of the screen
        populateWindow(window);
        window.pack();
    }

    /**
     * Add elements to Create New Maze page
     * provide an interface for the user to fill in details about the maze to be created
     * @author Jing Xuan Yew (n10426787)
     */
    @Override
    public void populateWindow(JFrame window) {

        // Create parent container mazePanel and set it up
        JPanel newMazePanel = new JPanel();
        newMazePanel.setLayout(new BoxLayout(newMazePanel, BoxLayout.PAGE_AXIS));
        newMazePanel.setVisible(true);
        newMazePanel.setBorder(BorderFactory.createEmptyBorder(LIGHT_PADDING, HEAVY_PADDING, HEAVY_PADDING, HEAVY_PADDING));
        window.add(newMazePanel);

        // Add a label to prompt the user to enter details for the maze
        Label titleLabel = new Label("Input maze details below:");
        Font titleFont = new Font(window.getFont().getFamily(), Font.BOLD, 14);
        titleLabel.setFont(titleFont.deriveFont(titleFont.getStyle() | Font.BOLD));

        // Create a JPanel for the Name & Author text input fields
        JPanel textFieldsPanel = new JPanel();
        textFieldsPanel.setLayout(new BoxLayout(textFieldsPanel, BoxLayout.Y_AXIS));
        textFieldsPanel.setBorder(BorderFactory.createEmptyBorder(0,0,0,TEXTBOX_PADDING));
        Label authorNameLabel = new Label("Enter author name:");
        authorNameField = new TextField();
        Label mazeTitleLabel = new Label("Enter maze title:");
        mazeTitleField = new TextField();
        authorNameField.setMaximumSize(new Dimension(WINDOW_WIDTH, TEXTBOX_HEIGHT));
        mazeTitleField.setMaximumSize(new Dimension(WINDOW_WIDTH, TEXTBOX_HEIGHT));
        textFieldsPanel.add(authorNameLabel);
        textFieldsPanel.add(authorNameField);
        textFieldsPanel.add(mazeTitleLabel);
        textFieldsPanel.add(mazeTitleField);

        // Create a JPanel to contain the sliders for maze Difficulty and cell size
        JPanel sliderPanel = new JPanel();
        sliderPanel.setLayout(new BoxLayout(sliderPanel, BoxLayout.Y_AXIS));
        Label difficultyText = new Label("Choose the difficulty of your maze:");
        mazeDifficulty = new JSlider();
        mazeDifficulty.setMajorTickSpacing(10);
        mazeDifficulty.setPaintLabels(true);
        mazeDifficulty.setPaintTicks(true);
        sliderPanel.add(difficultyText);
        sliderPanel.add(mazeDifficulty);
        sliderPanel.add(Box.createRigidArea(new Dimension(0,LIGHT_PADDING)));

        Label mazeCellSizeText = new Label("Choose the size of each cell in the maze (in pixels):");
        mazeCellSize = new JSlider();
        mazeCellSize.setMaximum(50);
        mazeCellSize.setValue(20);
        mazeCellSize.setMajorTickSpacing(5);
        mazeCellSize.setPaintLabels(true);
        mazeCellSize.setPaintTicks(true);
        sliderPanel.add(mazeCellSizeText);
        sliderPanel.add(mazeCellSize);
        sliderPanel.add(Box.createRigidArea(new Dimension(0,LIGHT_PADDING)));


        // Add JPanels to contain the width and height input fields and text
        Label mazeSize = new Label("Enter the size of your maze:");
        JPanel widthPanel = new JPanel();
        JPanel heightPanel = new JPanel();
        widthPanel.setLayout(new FlowLayout(FlowLayout.LEFT));
        heightPanel.setLayout(new FlowLayout(FlowLayout.LEFT));
        Label width = new Label("Width:");
        Label height = new Label("Height:");
        mazeWidthField = new TextField(1);
        mazeHeightField = new TextField(1);
        mazeWidthField.setMaximumSize(new Dimension(100, TEXTBOX_HEIGHT + 2));
        mazeHeightField.setMaximumSize(new Dimension(100, TEXTBOX_HEIGHT));
        widthPanel.add(width);
        widthPanel.add(Box.createHorizontalGlue());
        widthPanel.add(mazeWidthField);
        heightPanel.add(height);
        heightPanel.add(mazeHeightField);

        // Create a JPanel to contain the 'upload logo image' text and 'choose file' button
        JPanel logoPanel = new JPanel();
        logoPanel.setLayout(new FlowLayout(FlowLayout.LEFT));
        Label mazeLogoLabel = new Label("Upload logo image:");
        JButton mazeLogo = new JButton("Choose File");
        mazeLogo.addActionListener(new ActionListen());
        mazeLogo.setActionCommand("Choose File");
        logoPanel.add(mazeLogoLabel);
        logoPanel.add(mazeLogo);

        // Create a JPanel to contain the two bottom buttons regarding maze generation
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.LINE_AXIS));
        JButton createMazeScratch = new JButton("Create maze from scratch");
        JButton createMazeAuto = new JButton("Create auto generated maze");
        createMazeScratch.addActionListener(new ActionListen());
        createMazeAuto.addActionListener(new ActionListen());
        createMazeScratch.setActionCommand("Scratch_Maze");
        createMazeAuto.setActionCommand("Auto_Maze");
        buttonPanel.add(createMazeScratch);
        buttonPanel.add(Box.createRigidArea(new Dimension(LIGHT_PADDING,0)));
        buttonPanel.add(createMazeAuto);

        newMazePanel.add(titleLabel);
        newMazePanel.add(textFieldsPanel);
        newMazePanel.add(sliderPanel);
        newMazePanel.add(mazeSize);
        newMazePanel.add(widthPanel);
        newMazePanel.add(heightPanel);
        newMazePanel.add(logoPanel);
        newMazePanel.add(buttonPanel);
    }

    /**
     * A helper method to quickly add JMenuItem objects to a JMenu
     * @param text The text to be shown on the menu item, which is also its ActionCommand string
     * @param menu The JMenu we want to add the JMenuItem to
     * @author Jing Xuan Yew (n10426787)
     */
    public void newMenuItem(String text, JMenu menu) {
        JMenuItem item = new JMenuItem(text);
        item.addActionListener(new ActionListen()); // Add action listeners for the menu items and define their action commands
        item.setActionCommand(text); // Set the action listener command to be the same as its name
        menu.add(item); // add the new menu item to the menu
    }

    /**
     * Short method to set up the menu bar items for the MazeCreate Window
     * @return A JMenuBar object that can be displayed in a JFrame
     * @author Jing Xuan Yew (n10426787)
     */
    public JMenuBar createMenuBar() {

        // Create menu bar
        JMenuBar menuBar;
        menuBar = new JMenuBar();

        // Add Back Button to the menu bar
        JButton backButton = new JButton("< Back");
        backButton.setOpaque(false);
        backButton.setContentAreaFilled(false);
        backButton.setBorderPainted(false);
        backButton.addActionListener(new ActionListen());
        backButton.setActionCommand("Back");
        menuBar.add(backButton);

        // Make menu bar item align to the right
        menuBar.add(Box.createHorizontalGlue());

        // Create 'help' menu item
        JMenu help = new JMenu("   Help   ");
        menuBar.add(help);

        // Add menu item to 'Help' menu
        newMenuItem("Instructions", help);


        return menuBar;
    }


    private String mazeAuthorText = null, mazeTitleText = null;
    private int difficulty, gridX, gridY, cellSize;

    /**
     * Method to handle throwing exceptions for cases where the user does not input the required information
     * @throws IllegalArgumentException Thrown when user fails to provide input for a required field
     */
    public void setMazeField() throws IllegalArgumentException{

        if (authorNameField.getText().isBlank()){
            throw new IllegalArgumentException("Maze author cannot be empty!");
        }else
            this.mazeAuthorText = authorNameField.getText();

        if(mazeTitleField.getText().isBlank())
            throw new IllegalArgumentException("Maze title cannot be empty!");
        else
            this.mazeTitleText = mazeTitleField.getText();

        if (mazeDifficulty.getValue() == ' ')
            throw new IllegalArgumentException("Illegal difficulty (Must be between 0 and 100)");
        else
            this.difficulty = mazeDifficulty.getValue();

        if (mazeCellSize.getValue() == ' ')
            throw new IllegalArgumentException("Illegal cell size (Must be at least 1)");
        else
            this.cellSize = mazeCellSize.getValue();

        if (mazeWidthField.getText().isBlank())
            throw new IllegalArgumentException("Width cannot be empty!");
        else
            this.gridX = Integer.parseInt(mazeWidthField.getText()) + 2;

        if (mazeHeightField.getText().isBlank())
            throw new IllegalArgumentException("Height cannot be empty!");
        else
            this.gridY = Integer.parseInt(mazeHeightField.getText()) + 2;
    }

    public void setMazeFieldTest(String mazeAuthorText, String mazeTitleText, int difficulty, int gridX, int gridY, int cellSize){
        this.mazeAuthorText = mazeAuthorText;
        this.mazeTitleText = mazeTitleText;
        this.difficulty = difficulty;
        this.cellSize = cellSize;
        this.gridX = gridX;
        this.gridY = gridY;
    }

    /**
     * Method to create and return a new maze Object according to the type and details the user specifies
     * @param type The maze type, either "Manual" or "Auto"
     * @param unitTest Boolean var used for unit testing
     * @return Maze object with fields set according to the users inputs
     * @throws IllegalArgumentException Thrown when user (or software) fails to provide input for a required field
     */
    public Maze createMazeObject(String type, boolean unitTest) throws IllegalArgumentException {
        
        Maze maze = null;


        try {
            if(!unitTest){
                try{
                    setMazeField();
                } catch (Exception e){
                    throw new IllegalArgumentException(e);
                }
            }
            if(type.equals("Manual")) {
                try {
                    maze = new ManualMaze(mazeTitleText, mazeAuthorText, gridY, gridX, cellSize, logo);
                } catch (Exception e) {
                    throw new IllegalArgumentException(e);
                }
            } else if (type.equals("Auto")) {
                try {
                    maze = new AutoMaze(mazeTitleText, mazeAuthorText, gridY, gridX, cellSize, difficulty, logo);
                } catch (Exception e) {
                    throw new IllegalArgumentException(e);
                }

            }
        } catch (IllegalArgumentException except){
            String test = except.getMessage();
            String message;
            message = "Invalid input - " + test.replace("java.lang.IllegalArgumentException:", "").trim();
            JOptionPane warning = new JOptionPane();
            JOptionPane.showMessageDialog(warning, message , "Invalid input" ,JOptionPane.WARNING_MESSAGE);
            throw new IllegalArgumentException(except);

        } catch (Exception except) {
            JOptionPane warning = new JOptionPane();
            String message = "Please make sure you have entered data into all of the relevant fields.";
            JOptionPane.showMessageDialog(warning, message , "Missing data" ,JOptionPane.WARNING_MESSAGE);
        }
        return maze;
    }

    /**
     * Internal class that implements ActionListener
     * So that the outer class can use its features.
     * @author Jing Xuan Yew (n10426787)
     */
    private class ActionListen implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {

            String command = e.getActionCommand();

            switch (command){
                case "Scratch_Maze":
                    Maze manMaze;
                    try {
                        manMaze = createMazeObject("Manual", false);
                    } catch (Exception ex) {
                        throw new RuntimeException(ex);
                    }
                    killJFrame();
                    openMazeEdit(manMaze);
                    break;
                case "Auto_Maze":
                    AutoMaze autoMaze;
                    try {
                        autoMaze = (AutoMaze)createMazeObject("Auto", false);
                    } catch (Exception ex) {
                        throw new RuntimeException(ex);
                    }
                    CellGrid grid = autoMaze.generateMaze(autoMaze);
                    autoMaze.setCellGrid(grid);
                    killJFrame();
                    openMazeEdit(autoMaze);
                    break;
                case "Back":
                    killJFrame();
                    openLandingPage();
                    break;
                case "Choose File":
                    JFileChooser fileChooser = new JFileChooser();
                    int choice = fileChooser.showOpenDialog(programWindow);
                    if(choice == JFileChooser.APPROVE_OPTION) {
                        File file = fileChooser.getSelectedFile();
                        try {
                            FileInputStream fin = new FileInputStream(file);
                            if (logo == null) {
                                logo = new Logo(ImageIO.read(fin), 2);
                            } else {
                                logo.setBufferedImg(ImageIO.read(fin));
                            }
                        } catch (IOException ex) {
                            ex.printStackTrace();
                        }

                    }
                    break;
                case "Instructions":
                    JOptionPane instructions = new JOptionPane();
                    final String instructionMessage =
                            "<html><div style=\"padding-right:20px;\">Input Maze Details<br />" +
                                    "1. Author Name - Enter name of Maze Creator <br>" +
                                    "2. Maze Title - Enter name of Maze <br>" +
                                    "3. Maze Difficulty - Drag to choose difficulty level (Level 0 - Level 100) <br>" +
                                    "4. Size of each maze cells - Drag to choose size (must be bigger than 0) <br>" +
                                    "5. Maze Width - Numbers (from 1 to 100 only) <br>" +
                                    "6. Maze Height - Numbers (from 1 to 100 only) <br>" +
                                    "7. Maze Logo - Select image file from computer <br>" +
                                    "</div></html>";
                    JOptionPane.showMessageDialog(instructions, instructionMessage,"Instructions", JOptionPane.INFORMATION_MESSAGE);
                default:
                    break;
            }
        }
    }
}


