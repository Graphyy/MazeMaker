package GUI;

import DBUtils.MazeData;
import GUI.Graphics.DrawPanel;
import MazeUtils.DisplayMaze;
import MazeUtils.MazeDataTypes.Maze;

import javax.swing.*;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableColumnModel;
import javax.swing.table.TableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;


/**
 * Allows user to browse, preview, and load mazes from the database
 */
public class MazeDBBrowse extends MazeGUI implements Runnable {

    private static final int WINDOW_WIDTH = 700;
    private static final int WINDOW_HEIGHT = 800;

    final MazeData mazeDB;
    Maze maze;
    DrawPanel drawPanel;
    int row;

    public MazeDBBrowse(MazeData data) {
        this.mazeDB = data;
    }

    /**
     * Method used when invoking a new instance of MazeDBBrowse
     * that ensures threading is properly handled
     */
    @Override
    public void run() {
        programWindow = createWindow();
        setupWindow(programWindow);
    }

    /**
     * Specific implementation of createWindow that creates a JFrame
     * to contain the GUI elements and sets its parameters.
     */
    @Override
    public JFrame createWindow () {
        JFrame window = new JFrame("Maze Maker - Browse Maze Database");
        window.setVisible(true); // Make it so we can see the JFrame
        window.addWindowListener(new WindowAdapter() {  // Program will return to Landing Page if window is closed via the X
            @Override
            public void windowClosing(WindowEvent e) {
                killJFrame();
                openLandingPage();
            }
        });


        Dimension dimension = Toolkit.getDefaultToolkit().getScreenSize();
        int x = (int) ((dimension.getWidth() - WINDOW_WIDTH) / 2);
        int y = (int) ((dimension.getHeight() - WINDOW_HEIGHT) / 2);
        window.setLocation(x, y);

        return window;
    }

    /**
     * Method that sets up the newly created JFrame and adds elements to it
     */
    @Override
    public void setupWindow(JFrame window) {
        window.setPreferredSize(new Dimension(WINDOW_WIDTH,WINDOW_HEIGHT));
        window.setMinimumSize(new Dimension(WINDOW_WIDTH, WINDOW_HEIGHT));
        window.setJMenuBar(createMenuBar()); // Set up the menu bar at the top of the screen
        window.setResizable(false);
        populateWindow(window);
        window.pack();
    }

    /**
     * Method that populates the JFrame with the various GUI elements
     * @param window The JFrame we are adding elements to
     */
    @Override
    public void populateWindow(JFrame window) {

        JPanel parentPanel = new JPanel();
        parentPanel.setLayout(new BoxLayout(parentPanel, BoxLayout.Y_AXIS));
        parentPanel.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));

        JPanel mazeSearchPanel = new JPanel();
        mazeSearchPanel.setLayout(new BoxLayout(mazeSearchPanel, BoxLayout.LINE_AXIS));
        mazeSearchPanel.setMaximumSize(new Dimension(WINDOW_WIDTH - 50, 25));

        JLabel mazeSearchText = new JLabel("Search Maze:");
        mazeSearchPanel.add(mazeSearchText);
        mazeSearchPanel.add(Box.createRigidArea(new Dimension(5,10)));
        JTextField mazeSearchBar = new JTextField(1);
        mazeSearchPanel.add(mazeSearchBar);
        mazeSearchPanel.add(Box.createRigidArea(new Dimension(5,10)));


        // Should consider some sort of tableModel for this
        JPanel mazeListPanel = new JPanel();
        mazeListPanel.setLayout(new BoxLayout(mazeListPanel, BoxLayout.Y_AXIS));
        mazeListPanel.setPreferredSize(new Dimension(WINDOW_WIDTH, 50));

        JPanel mazeViewPanel = new JPanel();
        mazeViewPanel.setLayout(new BoxLayout(mazeViewPanel, BoxLayout.PAGE_AXIS));
        JScrollPane mazeViewScroll = new JScrollPane(); // Need to insert the DrawPanel Here
        mazeViewScroll.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED);
        mazeViewScroll.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        mazeViewPanel.add(mazeViewScroll);

        JTable mazeTable = new JTable(mazeDB.tableModelwithDate());
        ListSelectionModel lsi = mazeTable.getSelectionModel();
        lsi.addListSelectionListener(e -> {
            if(row != -1){
                row = mazeTable.getSelectedRow();
                int mazeID = (int) mazeTable.getValueAt(row,0);
                maze = mazeDB.getMazeObject(mazeID);
                maze = mazeDB.getMazeObject(mazeID);
                DisplayMaze displayMaze = new DisplayMaze(maze);
                drawPanel = displayMaze.initialiseGUIObjects();
                mazeViewScroll.add(drawPanel);
                mazeViewScroll.setViewportView(drawPanel); // Set viewport to the DrawPanel
            }
        });

        JButton mazeSearchButton = new JButton("Search");
        mazeSearchPanel.add(mazeSearchButton);
        mazeSearchButton.addActionListener(new MazeDBBrowse.ActionListen(){
            @Override
            public void  actionPerformed(ActionEvent e){
                row=-1; // clear selected row value
                String search = mazeSearchBar.getText();
                if(!search.equals("")) {
                    TableModel searchModel = mazeDB.searchModel(search);
                    mazeTable.setModel(searchModel);
                }
                else{
                    TableModel tableModel = mazeDB.tableModel();
                    mazeTable.setModel(tableModel);
                }
                mazeTable.getColumnModel().getColumn(0).setMaxWidth(100);
                mazeTable.getColumnModel().getColumn(1).setMaxWidth(300);
                mazeTable.getColumnModel().getColumn(2).setMaxWidth(300);
                row=0;
            }
        });

        JTableHeader header = mazeTable.getTableHeader();
        TableColumnModel model = header.getColumnModel();

        JScrollPane mazeListScroll = new JScrollPane(mazeTable);
        mazeListScroll.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        mazeListPanel.add(mazeListScroll);

        // Create a button for maze Loading
        JPanel loadMazePanel = new JPanel();
        loadMazePanel.setLayout(new BoxLayout(loadMazePanel, BoxLayout.X_AXIS));
        loadMazePanel.setMaximumSize(new Dimension(WINDOW_WIDTH, 50));

        JButton loadMaze = new JButton("Load Maze");
        loadMaze.addActionListener(e -> {
            if (e.getActionCommand().equals("Load")) {

                if (maze == null){
                    JOptionPane.showMessageDialog(programWindow,
                            "No maze selected!",
                            "Warning",
                            JOptionPane.WARNING_MESSAGE);
                } else {
                    killJFrame();
                    openMazeEdit(maze);
                }
            }
        });
        loadMaze.setActionCommand("Load");
        loadMaze.setPreferredSize(new Dimension(80, 25));
        loadMazePanel.add(loadMaze);

        JPanel mazeViewLabelPanel = new JPanel();
        mazeViewLabelPanel.setLayout(new BoxLayout(mazeViewLabelPanel, BoxLayout.X_AXIS));
        JLabel mazeViewLabel = new JLabel("Maze Preview:");
        mazeViewLabelPanel.add(mazeViewLabel);

        parentPanel.add(mazeSearchPanel);
        parentPanel.add(Box.createRigidArea(new Dimension(WINDOW_WIDTH, 20)));
        parentPanel.add(mazeListPanel);
        parentPanel.add(Box.createRigidArea(new Dimension(WINDOW_WIDTH, 10)));
        parentPanel.add(loadMazePanel);
        parentPanel.add(Box.createRigidArea(new Dimension(WINDOW_WIDTH, 20)));
        parentPanel.add(mazeViewLabelPanel);
        parentPanel.add(Box.createRigidArea(new Dimension(WINDOW_WIDTH, 5)));
        parentPanel.add(mazeViewPanel);

        window.add(parentPanel);

    }

    /**
     * Short method to set up the menu bar items for the MazeEdit Window
     * @return A JMenuBar object that can be displayed in a JFrame
     * @author Elliott McGrath (n9701958)
     */
    private JMenuBar createMenuBar() {

        // Create the menu bar
        JMenuBar menuBar;
        menuBar = new JMenuBar();

        // Add Back Button to the menu bar
        JButton backButton = new JButton("< Back");
        backButton.setOpaque(false);
        backButton.setContentAreaFilled(false);
        backButton.setBorderPainted(false);
        backButton.addActionListener(new ActionListen());
        backButton.setActionCommand("Back");
        menuBar.add(backButton);

        // Make menu bar item align to the right
        menuBar.add(Box.createHorizontalGlue());

        return menuBar;
    }

    /**
     * A helper method to quickly add JMenuItem objects to a JMenu
     * @param text The text to be shown on the menu item, which is also its ActionCommand string
     * @param menu The JMenu we want to add the JMenuItem to
     * @author Elliott McGrath (n9701958)
     */
    private void newMenuItem(String text, JMenu menu) {
        JMenuItem item = new JMenuItem(text);
        item.addActionListener(new ActionListen()); // Add action listeners for the menu items and define their action commands
        item.setActionCommand(text); // Set the action listener command to be the same as its name
        menu.add(item); // add the new menu item to the menu
    }

    /**
     * Internal class that implements ActionListener
     * So that the outer class can use its features.
     * @author Elliott McGrath (n9701958)
     */
    private class ActionListen implements ActionListener {
        /**
         * Action event handler to work with interactive UI elements
         * @param e ActionEvent object which contains information such as the ActionCommand
         */
        @Override
        public void actionPerformed(ActionEvent e) {
            String command = e.getActionCommand();
            if (command.equals("Back")) {
                killJFrame();
                openLandingPage();
            }
        }

    }

}
