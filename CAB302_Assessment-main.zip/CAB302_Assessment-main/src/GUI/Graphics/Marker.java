package GUI.Graphics;

import javax.swing.*;
import java.awt.*;

/**
 * Class establishing the information to be stored about the positional marker
 * that is drawn on screen in the MazeEdit window
 * @author Elliott McGrath (n9701958)
 */
public class Marker extends JComponent {

    final Rectangle rect;
    final int cellSize;
    boolean isVisible;

    public Marker(int cellSize) {
        this.cellSize = cellSize;
        this.rect = new Rectangle();
        this.isVisible = false;
        this.rect.width = 0;
        this.rect.height = 0;
    }

    /**
     * If the marker is visible, make it invisible, and vice versa
     */
    void toggleMarkerVisibility() {
        if(this.isVisible) {
            rect.width = 0;
            rect.height = 0;
            this.isVisible = false;
        } else {
            rect.width = cellSize - 3;
            rect.height = cellSize - 3;
            this.isVisible = true;
        }
    }

    /**
     * Set the coordinates of the rectangle object which represents the marker drawn on mazeEdit screen
     * @param x The horizontal dimension of the marker in the grid
     * @param y The vertical dimension of the marker in the grid
     */
    void setRectCoords(int x, int y) {
        rect.x = x * cellSize + 2;
        rect.y = y * cellSize + 2;
    }

    /**
     * Fill in the marker rectangle with a blue colour
     * @param g2d The graphics object used by DrawPanel to render elements on screen
     * @param rect The rectangle object representing the marker to be drawn on screen
     */
    void fillRectangle(Graphics g2d, Rectangle rect) {
        g2d.setColor(Color.blue);
        g2d.fillRect(rect.x, rect.y, rect.width, rect.height);
    }

    /**
     * Override method for the graphics library to determine custom behaviour
     * for rendering of marker objects
     * @param g2d The graphics object used by DrawPanel to render elements on screen
     */
    @Override
    public void paintComponent(Graphics g2d) {
        fillRectangle(g2d, this.rect);
    }

}
