package GUI.Graphics;

import MazeUtils.MazeDataTypes.Cell;
import MazeUtils.MazeDataTypes.CellGrid;
import MazeUtils.MazeDataTypes.Logo;

import javax.swing.JComponent;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Font;
import java.awt.Image;
import java.awt.image.ImageObserver;
import java.io.Serial;
import java.util.ArrayList;
import java.util.List;

/**
 * Class to draw the contents of a maze panel
 * @author Elliott McGrath (n9701958)
 */
public class DrawPanel extends JComponent {

    private final int gridX, gridY, cellSize;
    private final CellGrid cellGrid;
    private final MarkerGrid markergrid;
    private Logo logo;
    public List<Cell>path;
    public Color color;

    public boolean drawLegend;
    public boolean drawPath;
    public boolean addColour;
    public boolean drawEntryExit;

    /**
     * Constructor for DrawPanel, a class used to represent the area within which graphics objects can be rendered
     * @param markergrid Markergrid object representing a grid of marker squares
     * @param cellgrid Cellgrid object containing vital maze data regarding structure and images
     * @param gridX The horizontal size of the maze grid
     * @param gridY The vertical size of the maze grid
     * @param cellSize The size of each square cell in pixels (both x and y dimension)
     * @param logo The logo image to be drawn in the maze area
     * @author Elliott McGrath (n9701958)
     */
    public DrawPanel(MarkerGrid markergrid, CellGrid cellgrid, int gridX, int gridY, int cellSize, Logo logo) {
        this.gridX = gridX;
        this.gridY = gridY;
        this.cellSize = cellSize;
        this.cellGrid = cellgrid;
        this.markergrid = markergrid;
        this.logo = logo;
        this.drawLegend = true;
        this.drawPath = false;
        this.addColour = false;
        this.drawEntryExit = false;
        setBackground(Color.white);
    }

    /**
     * Method used to render the grid that makes up the maze.
     * @param g2d Graphics object used by the DrawPanel to render elements on screen
     * @param grid Cellgrid object storing the maze structure data
     */
    public void drawGrid(Graphics g2d, CellGrid grid) {
        // Draw the sides of the squares
        for(int x = 0; x < gridX; x++) {
            for(int y = 0; y < gridY; y++) {
                if(grid.getCell(x,y).getAnyWall("UP")){
                    drawLine(x, y, grid, g2d, cellSize, "Top");
                }
                if(grid.getCell(x,y).getAnyWall("DOWN")){
                    drawLine(x, y, grid, g2d, cellSize, "Bottom");
                }
                if(grid.getCell(x,y).getAnyWall("LEFT")){
                    drawLine(x, y, grid, g2d, cellSize, "Left");
                }
                if(grid.getCell(x,y).getAnyWall("RIGHT")){
                    drawLine(x, y, grid, g2d, cellSize, "Right");
                }
            }
        }
    }


    /**
     * Code to draw  legend numbers on the mazeEdit screen
     * @param g2d Graphics object used by DrawPanel
     * @author Elliott McGrath (n9701958)
     */
    public void drawLegend(Graphics g2d) {
        // Setup some initial fields related to the legend rendering
        g2d.setColor(Color.BLACK);
        g2d.setFont(new Font (g2d.getFont().getFontName(), Font.PLAIN, (int)((float)cellSize / 1.5)));

        // Draw the X axis of the legend
        for(int x = 1; x < gridX - 1; x++) {
            if (x < 10) {
                g2d.drawString(Integer.toString(x), x * cellSize + (int)(((float)cellSize / 98) * 35) ,  (cellSize * 2) - (cellSize / 4) );
            } else {
                g2d.drawString(Integer.toString(x), x * cellSize + (int)(((float)cellSize / 98) * 18)  , (cellSize * 2) - (cellSize / 4) );
            }
        }

        // Draw the Y axis of the legend
        for(int y = 2; y < gridY - 1; y++) {
            if (y < 10) {
                g2d.drawString(Integer.toString(y), cellSize + (int)(((float)cellSize / 98) * 35), (y * cellSize) + (int)((float)cellSize / 1.33));
            } else {
                g2d.drawString(Integer.toString(y),cellSize +  (int)(((float)cellSize / 98) * 18),(y * cellSize) + (int)(((float)cellSize / 98) * 76));
            }
        }
    }


    /**
     * Code to draw a line between two points in a CellGrid
     * @param x horizontal position of the line start point
     * @param y vertical position of the line start point
     * @param grid The cellgrid used to retrieve cell information
     * @param g2d the graphics object being used by the DrawPanel
     * @param cellSize Size of each cell in pixels
     * @param side A string representing one of the four sides of each cell
     * @author Elliott McGrath (n9701958)
     */
    public void drawLine(int x, int y, CellGrid grid, Graphics g2d, int cellSize, String side) {
        if(side.equals("Right")) {
            g2d.drawLine(grid.getCell(x,y).getXPos() + cellSize , grid.getCell(x,y).getYPos() , grid.getCell(x,y).getXPos() + cellSize ,grid.getCell(x,y).getYPos() + cellSize);
        }
        if(side.equals("Left")) {
            g2d.drawLine(grid.getCell(x,y).getXPos(), grid.getCell(x,y).getYPos() , grid.getCell(x,y).getXPos() ,grid.getCell(x,y).getYPos() + cellSize );
        }
        if(side.equals("Bottom")) {
            g2d.drawLine(grid.getCell(x,y).getXPos() , grid.getCell(x,y).getYPos() + cellSize, grid.getCell(x,y).getXPos() + cellSize , grid.getCell(x,y).getYPos() + cellSize);
        }
        if(side.equals("Top")) {
            g2d.drawLine(grid.getCell(x,y).getXPos(), grid.getCell(x,y).getYPos(), grid.getCell(x,y).getXPos() + cellSize, grid.getCell(x,y).getYPos());
        }
    }

    /**
     * Method to render the optimal path calculated by the maze solver on screen
     * @param g The graphics object used by DrawPanel to render elements on screen
     */
    public void drawPath(Graphics g){
        for(Cell item:path) {
            int[]coords = item.getCoords();
            g.drawRect(coords[0]+6, coords[1]+6, cellSize-12, cellSize-12);
            g.fillRect(coords[0]+6, coords[1]+6, cellSize-12, cellSize-12);
        }

    }

    /**
     * Code to render a logo image within the maze editing window
     * @param g2d Graphics object used by DrawPanel
     * @param cellGrid data structure containing essential maze data (structure, logos, etc)
     * @author Elliott McGrath (n9701958)
     */
    public void drawLogo(Graphics g2d, CellGrid cellGrid) {
        ArrayList<int[]> logoCoords = cellGrid.getLogoCoords();

        ImageObserver comp = new JComponent() {
            @Serial
            private static final long serialVersionUID = 1L;
        };

        Image tmp = logo.getBufferedImg().getScaledInstance((cellSize * 2) - 1 , (cellSize * 2) - 1, Image.SCALE_SMOOTH);


        if (logoCoords.isEmpty()) {
            cellGrid.setLogoCoords(2, 2, 2);
        }


        try {
            g2d.drawImage(tmp, (logoCoords.get(0)[0] * cellSize) + 1, (logoCoords.get(0)[1] * cellSize) + 1, comp);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    /**
     * Draw the entry and exit indicators for the maze
     * @param g Graphics object used by DrawPanel
     */
    public void drawEntryExit(Graphics g){
        String[] start_coords = cellGrid.entryCell;
        String[] end_coords = cellGrid.exitCell;
        Cell start = cellGrid.getCell(Integer.parseInt(start_coords[0]),Integer.parseInt(start_coords[1]));
        Cell end = cellGrid.getCell(Integer.parseInt(end_coords[0]),Integer.parseInt(end_coords[1]));

        int[] intstart_coords = start.getCoords();
        int[] intend_coords = end.getCoords();

        //draw entry
        g.setColor(Color.GREEN);
        g.drawOval(intstart_coords[0]+3,intstart_coords[1]+3,cellSize-6,cellSize-6);
        g.fillOval(intstart_coords[0]+3,intstart_coords[1]+3,cellSize-6,cellSize-6);

        //draw exit
        g.setColor(Color.RED);
        g.drawOval(intend_coords[0]+3,intend_coords[1]+3,cellSize-6,cellSize-6);
        g.fillOval(intend_coords[0]+3,intend_coords[1]+3,cellSize-6,cellSize-6);
    }

    /**
     * A method to set the locally stored logo variable for redrawing while editing
     * @param logo Logo image to be displayed within the maze
     */
    public void setLogo(Logo logo) {
        this.logo = logo;
    }

    /**
     * Getter method used to scale the display panels in mazeExport
     */
    public int getCellSize() {
        return cellSize;
    }

    /**
     * Getter method used to scale the display panels in mazeExport
     */
    public CellGrid getCellGrid() {
        return cellGrid;
    }


    /**
     * GUI.Graphics handler to combine super.paintComponent and the new method doDrawing.
     * @param g the <code>GUI.Graphics</code> object to protect
     */
    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        drawGrid(g, cellGrid);

        if (logo != null) {
            drawLogo(g, cellGrid);
        }

        if (markergrid != null) {
            markergrid.paintComponent(g);
        }

        if(drawLegend) {
            drawLegend(g);
        }
        if(drawPath){
            g.setColor(Color.PINK);
            drawPath(g);
        }
        if(addColour){
            g.setColor(color);
            drawPath(g);
        }
        if(drawEntryExit){
            drawEntryExit(g);
        }
    }
}
