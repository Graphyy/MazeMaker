package GUI.Graphics;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

/**
 * Class that creates a grid identical in size to that of the maze in
 * order to render the position marker in the correct location on the mazeEdit window
 */
public class MarkerGrid extends JComponent {

    private final ArrayList<ArrayList<Marker>> markerGrid;
    private final int gridX, gridY;

    /**
     * Constructor for MarkerGrid that sets several fields and
     * constructs the grid using nested ArrayLists and for loops
     * @param gridX The horizontal size of the maze in number of cells
     * @param gridY The vertical size of the maze in number of cells
     * @param cellSize The size of each cell in the maze in pixels
     */
    public MarkerGrid(int gridX, int gridY, int cellSize) {

        this.gridX = gridX;
        this.gridY = gridY;
        markerGrid = new ArrayList<>();

        // Create 'rows' within the array list, adding the Y dimension to our grid
        for (int i = 0; i < Math.max(gridX,gridY); i++) {
            markerGrid.add(new ArrayList<>());
        }

        // Add marker objects for every possible coordinate in the grid
        for(int x = 0; x < gridX; x++) {
            for(int y = 0; y < gridY; y++) {
                markerGrid.get(x).add(new Marker(cellSize));
            }
        }

        // Initialise coordinates for markers
        for(int x = 0; x < gridX; x++) {
            for(int y = 0; y < gridY; y++) {
                markerGrid.get(x).get(y).setRectCoords(x, y);
            }
        }
    }

    /**
     * Returns the horizontal size of the maze in number of cells
     * @return The horizontal size of the maze in number of cells
     */
    public int getGridX() {
        return gridX;
    }

    /**
     * Returns the vertical size of the maze in number of cells
     * @return The vertical size of the maze in number of cells
     */
    public int getGridY() {
        return gridY;
    }

    /**
     * Setter method for makeMarkerVisible method
     * that toggles the visibility of a marker square.
     * @param x The x coordinate of the marker to be toggled
     * @param y The y coordinate of the marker to be toggled
     */
    public void toggleMarkerVisible(int x, int y) {
        markerGrid.get(x).get(y).toggleMarkerVisibility();
    }

    /**
     * Override method for the graphics library to determine custom behaviour
     * for rendering of the markerGrid
     * @param g2d The graphics object used by DrawPanel to render elements on screen
     */
    @Override
    public void paintComponent(Graphics g2d) {
        for (int x = 0; x < getGridX(); x++) {
            for (int y = 0; y < getGridY(); y++) {
                markerGrid.get(x).get(y).paintComponent(g2d);
            }
        }
    }
}