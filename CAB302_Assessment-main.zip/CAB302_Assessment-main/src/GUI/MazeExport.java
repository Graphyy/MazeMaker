package GUI;

import DBUtils.MazeData;
import GUI.Graphics.DrawPanel;
import MazeUtils.DisplayMaze;
import MazeUtils.ExportMaze;
import MazeUtils.MazeDataTypes.Cell;
import MazeUtils.MazeDataTypes.CellGrid;
import MazeUtils.MazeDataTypes.Maze;
import MazeUtils.MazeSolver;

import javax.swing.*;
import javax.swing.table.TableModel;
import java.awt.*;
import java.awt.event.*;
import java.util.List;

/**
 * Sets up window that allows user to export mazes and solution images
 */
public class MazeExport extends MazeGUI implements Runnable{

    private final static int WINDOW_WIDTH = 720;
    private final static int WINDOW_HEIGHT = 850;
    private final static int MAZE_WINDOW_WH = 200;

    final MazeData data;
    Maze maze;
    JFrame mazeWindow;
    DrawPanel drawPanel;
    Graphics g;
    int row;
    List<Cell> path;

    /**
     * Method used when invoking a new instance of MazeEdit
     * that ensures threading is properly handled
     */
    @Override
    public void run() {
        programWindow = createWindow();
        mazeWindow = createMazeWindow();
        setupWindow(programWindow);
        setupMazeWindow(mazeWindow);
    }

    /**
     * @param data The underlying data/model class the UI needs.
     */
    public MazeExport(MazeData data){
        this.data = data;
    }

    /**
     * Specific implementation of createWindow that creates a JFrame
     * to contain the GUI elements, and sets its parameters.
     */
    @Override
    public JFrame createWindow () {
        JFrame window = new JFrame("Maze Maker");
        window.setVisible(true); // Make it so we can see the Jframe
        window.addWindowListener(new WindowAdapter() {  // Program will return to Landing Page if window is closed via the X
            @Override
            public void windowClosing(WindowEvent e) {
                killJFrame();
                mazeWindow.dispose();
                openLandingPage();
            }
        });

        // Make the window appear roughly in the center of the screen
        Dimension dimension = Toolkit.getDefaultToolkit().getScreenSize();
        int x = (int) ((dimension.getWidth() - (WINDOW_WIDTH / 2)) / 4);
        int y = (int) ((dimension.getHeight() - (WINDOW_HEIGHT / 2)) / 14);
        window.setLocation(x, y);

        return window;
    }

    /**
     * Special method for MazeExport used to create a smaller window to display the maze in alongside the mazeExport window.
     */
    public JFrame createMazeWindow () {
        JFrame window = new JFrame("Display Maze");
        window.setVisible(true); // Make it so we can see the Jframe
        window.addWindowListener(new WindowAdapter() {  // Program will return to Landing Page if window is closed via the X
            @Override
            public void windowClosing(WindowEvent e) {
                programWindow.dispose();
                killJFrame();
                openLandingPage();
            }
        });

        // Make the window appear next to the main one
        window.setLocationRelativeTo(programWindow);
        Point point = window.getLocation();
        point.x = point.x + WINDOW_WIDTH;
        window.setLocation(point);

        return window;
    }



    /**
     * Method that sets up the newly created JFrame and adds elements to it
     */
    @Override
    public void setupWindow(JFrame window) {
        window.setPreferredSize(new Dimension(WINDOW_WIDTH,WINDOW_HEIGHT));
        window.setResizable(false);
        window.setJMenuBar(createMenuBar()); //set up the menu bar at the top of the screen
        populateWindow(window);
        window.pack();
        window.setVisible(true);
    }

    /**
     * Method that sets up the newly created maze preview window and adds elements to it
     */
    public void setupMazeWindow(JFrame window) {
        window.setMinimumSize(new Dimension(MAZE_WINDOW_WH,MAZE_WINDOW_WH));
        window.setResizable(false);
        window.pack();
        window.setVisible(true);
    }

    /**
     * A helper method to quickly add JMenuItem objects to a JMenu
     * @param text The text to be shown on the menu item, which is also its ActionCommand string
     * @param menu The JMenu we want to add the JMenuItem to
     * @author Jing Xuan Yew (n10426787)
     */
    public void newMenuItem(String text, JMenu menu) {
        JMenuItem item = new JMenuItem(text);
        item.addActionListener(new MazeExport.ActionListen()); // Add action listeners for the menu items and define their action commands
        item.setActionCommand(text); // Set the action listener command to be the same as its name
        menu.add(item); // add the new menu item to the menu
    }

    /**
     * Short method to set up the menu bar items for the MazeExport Window
     * @return A JMenuBar object that can be displayed in a JFrame
     * @author Jing Xuan Yew (n10426787)
     */
    private JMenuBar createMenuBar(){
        //Create new menu bar
        JMenuBar menuBar = new JMenuBar();

        // Add Back Button to the menu bar
        JButton backButton = new JButton("< Back");
        backButton.setOpaque(false);
        backButton.setContentAreaFilled(false);
        backButton.setBorderPainted(false);
        backButton.addActionListener(new MazeExport.ActionListen());
        backButton.setActionCommand("Back");
        menuBar.add(backButton);


        menuBar.add(Box.createHorizontalGlue());

        //Create menu
        JMenu help = new JMenu("   Help   ");

        //Add menu to menu bar
        menuBar.add(help);

        //set the size of the frame
        menuBar.setVisible(true);
        newMenuItem("Instructions", help);
        return menuBar;
    }
    /**
     * Create elements for Maze Export Window
     * provide an interface for the user to select maze and export maze as a image file
     * @author Nini Kao (n10212469)
     */
    @Override
    public void populateWindow(JFrame window) {

        //Main Panel
        JPanel Panel = new JPanel( new FlowLayout(FlowLayout.CENTER, 0, 0));

        //Panel For SearchPanel and SelectPanel
        JPanel SSPanel = new JPanel(new BorderLayout());

        //Create Panels
        JPanel SearchPanel = new JPanel( new FlowLayout(FlowLayout.LEFT));
        JPanel SelectPanel = new JPanel();
        SelectPanel.setLayout(new BoxLayout(SelectPanel,BoxLayout.PAGE_AXIS));
        JPanel ShowPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JPanel ColourPanel = new JPanel(new FlowLayout());

        //Display
        JScrollPane DisplayPanel = new JScrollPane(JScrollPane.VERTICAL_SCROLLBAR_NEVER, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);


        //Set panel size
        SearchPanel.setPreferredSize( new Dimension(700,70));
        SelectPanel.setPreferredSize( new Dimension(700,230));
        ShowPanel.setPreferredSize(new Dimension(700,70));
        ColourPanel.setPreferredSize( new Dimension(700,360));
        DisplayPanel.setMinimumSize( new Dimension(200,200));

        //set title on each Panel
        SearchPanel.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createEtchedBorder(),"Search Maze"));

        SelectPanel.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createEtchedBorder(),"Select Maze"));

        ShowPanel.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createEtchedBorder(),"Show In Maze"));

        ColourPanel.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createEtchedBorder(),"Select Colour Line"));


        /*
         * Create a checkbox that interact with the display Maze window.
         * When item state is changed, the solution of the maze will display in
         * the Display window.
         */
        JCheckBox showPath = new JCheckBox("Show Optimal Path");
        showPath.setSelected(false);
        showPath.addItemListener(e -> {
            if (e.getStateChange() == ItemEvent.SELECTED) {
                if(maze != null){
                    g = drawPanel.getGraphics();
                    CellGrid cellGrid = maze.getCellGrid();
                    String[] start_coords = cellGrid.entryCell;
                    String[] end_coords = cellGrid.exitCell;
                    Cell start = cellGrid.getCell(Integer.parseInt(start_coords[0]),Integer.parseInt(start_coords[1]));
                    Cell end = cellGrid.getCell(Integer.parseInt(end_coords[0]),Integer.parseInt(end_coords[1]));
                    MazeSolver solveMaze = new MazeSolver(maze, drawPanel.getCellGrid(), g,start, end, drawPanel.getCellSize());
                    path = solveMaze.DFS();
                    if(path !=null){
                        drawPanel.drawPath = true;
                        drawPanel.path = path;
                        DisplayPanel.paint(g);
                    }
                    else {
                        Pop_unsolvable();
                    }
                }
                else{
                    Pop();
                }
            }
            if (e.getStateChange() != ItemEvent.SELECTED) {
                drawPanel.drawPath = false;
                drawPanel.path = null;
                drawPanel.addColour = false;
                drawPanel.repaint();
            }
        });

        /*
         * Create a checkbox that interact with the display Maze window.
         * When item state is changed, entry and exit and will display in
         * the Display window.
         */
        //Create CheckBox
        JCheckBox showEntryExit = new JCheckBox("Show Entry Exit");
        showEntryExit.setSelected(false);
        showEntryExit.addItemListener(e -> {
            if (e.getStateChange() == ItemEvent.SELECTED) {
                if(maze != null){
                    g = drawPanel.getGraphics();
                    drawPanel.drawEntryExit = true;
                    DisplayPanel.paint(g);
                }
                else{
                    Pop();
                }
            }
            if (e.getStateChange() != ItemEvent.SELECTED) {
                drawPanel.drawEntryExit = false;
                drawPanel.repaint();
            }
        });


        //Create text input
        JTextField searchInput = new JTextField(52);

        //Create list
        JList<String> mazeList = new JList<>(data.getModel());
        mazeList.setPreferredSize(new Dimension(260,220));

        /*
         * Create a table that interact with all the maze saved in the database
         * Maze id, Name and Author will be shown in the table.
         * Selecting the row will interact with the display maze window. A maze will be
         * display when maze is fetch from the database
         */
        JTable mazetbl = new JTable(data.tableModel());
        mazetbl.getColumnModel().getColumn(0).setMaxWidth(100);
        mazetbl.getColumnModel().getColumn(1).setMaxWidth(300);
        mazetbl.getColumnModel().getColumn(2).setMaxWidth(300);


        /*
         * Create A search button that interact with the Mazeco database
         * Search Query is execute when button is clicked.
         * Search Query will be search the input string in maze name column.
         */
        JButton searchBtn = new JButton("search");
        searchBtn.addActionListener(new ActionListen(){
            @Override
            public void  actionPerformed(ActionEvent e){
                row=-1; // clear selected row value
                String search = searchInput.getText();
                if(!search.equals("")) {
                    TableModel searchModel = data.searchModel(search);
                    mazetbl.setModel(searchModel);
                }
                else{
                    TableModel tableModel = data.tableModel();
                    mazetbl.setModel(tableModel);
                }
                mazetbl.getColumnModel().getColumn(0).setMaxWidth(100);
                mazetbl.getColumnModel().getColumn(1).setMaxWidth(300);
                mazetbl.getColumnModel().getColumn(2).setMaxWidth(300);
                row=0;
            }
        });
        searchBtn.setPreferredSize(new Dimension(75,20));
        searchBtn.setMaximumSize(new Dimension(75,20));

        //table selection listener
        mazetbl.getSelectionModel().addListSelectionListener(e -> {
            //get maze data
            if(row!=-1){
                showPath.setSelected(false);
                row = mazetbl.getSelectedRow();
                int mazeID = (int) mazetbl.getValueAt(row,0);
                maze = data.getMazeObject(mazeID);
                DisplayMaze displayMaze = new DisplayMaze(maze);
                drawPanel = displayMaze.initialiseGUIObjects();
                //window and panel size
                int width = maze.getWidth()*drawPanel.getCellSize();
                int height = maze.getHeight()*drawPanel.getCellSize();
                mazeWindow.setSize(new Dimension(width+20, height+40));
                DisplayPanel.setSize(new Dimension(width+10, height+10));
                DisplayPanel.add(drawPanel);
                DisplayPanel.setViewportView(drawPanel);
            }

            // Set viewport to the DrawPanel
        });

        /*
         * Create Colour Palette  that interact with the optimal path checkbox.
         * When colour is choosen in the Colour Palette, the colour of optimal path
         * will change.
         */
        JColorChooser colorChooser = new JColorChooser();
        colorChooser.getSelectionModel().addChangeListener(e -> {
            //choose colour
            Color newPathColor = colorChooser.getColor();
            if(maze != null){
                if(showPath.isSelected()){
                    g = drawPanel.getGraphics();
                    //panel size
                    int width = maze.getWidth()*maze.getCellSize();
                    int height = maze.getHeight()*maze.getCellSize();
                    DisplayPanel.setSize(new Dimension(width, height));

                    //set up maze
                    if(path !=null){
                        drawPanel.drawPath = true;
                        drawPanel.path = path;
                        drawPanel.addColour = true;
                        drawPanel.color = newPathColor;
                        DisplayPanel.paint(g);
                    }
                    else {
                        Pop_unsolvable();
                    }
                }
                if(!showPath.isSelected()){
                    Pop_showbox();
                    drawPanel.drawPath = false;
                    drawPanel.path = null;
                    drawPanel.addColour = false;
                    drawPanel.repaint();

                }
            }
            else{
                Pop();
            }
        });

        //Create export Button
        JButton exportBtn = new JButton("Export");
        exportBtn.setPreferredSize(new Dimension(75,30));
        exportBtn.addActionListener(new ActionListen(){
            public void actionPerformed(ActionEvent e){
                try{
                    ExportMaze.getSaveSnapShot(DisplayPanel);
                }
                catch (Exception except){
                    except.printStackTrace();
                }
            }
        });

        //Add to Panel
        SearchPanel.add(new JLabel("")); //for empty cell
        SearchPanel.add(searchInput);
        SearchPanel.add(searchBtn);

        SelectPanel.add(mazetbl);
        SelectPanel.add(new JScrollPane(mazetbl));

        ShowPanel.add(showPath);
        ShowPanel.add(showEntryExit);

        ColourPanel.add(colorChooser);

        //Add panels to Main Panel
        SSPanel.add(SearchPanel,BorderLayout.NORTH);
        SSPanel.add(SelectPanel,BorderLayout.SOUTH);
        Panel.add(SSPanel,BorderLayout.WEST);
        Panel.add(ShowPanel,BorderLayout.SOUTH);
        //Panel.add(DisplayPanel,BorderLayout.EAST);
        Panel.add(ColourPanel,BorderLayout.SOUTH);
        Panel.add(exportBtn);

        //Add Panels to Main Window
        window.add(Panel);
        mazeWindow.add(DisplayPanel);

    }

    /**
     * Internal class that implements ActionListener
     * So that the outer class can use its features.
     * @author Elliott McGrath (n9701958)
     */
    private class ActionListen implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            String command = e.getActionCommand();

            switch (command){
                case "Back":
                    killJFrame();
                    openLandingPage();
                    break;
                case "Instructions":
                    JOptionPane instructions = new JOptionPane();
                    final String instructionMessage =
                            "<html><div style=\"padding-right:20px;\"><br />" +
                                    "1. Search maze by entering Maze Name<br>" +
                                    "2. Select a Maze from the table to view maze on the DisplayMaze panel <br>" +
                                    "3. Check 'Show Optimal Path' checkbox to view maze solution<br>" +
                                    "4. Check 'Show Entry Exit' checkbox to view maze entrance and exit location<br>" +
                                    "5. Change maze solution path colour by selecting colours from the colour palette <br>" +
                                    "6. Export Maze into image file by clicking on Export button<br>" +
                                    "</div></html>";
                    JOptionPane.showMessageDialog(instructions, instructionMessage,"Export Maze Instructions", JOptionPane.INFORMATION_MESSAGE);
                default:
                    break;
            }
        }
    }
    /**
     * A pop up screen when maze is not selected
     * @author Nini Kao (n10212469)
     */
    public void Pop(){
        JFrame jFrame = new JFrame();
        JOptionPane.showMessageDialog(jFrame,"No Maze is selected");
    }

    /**
     * A pop up screen when maze cannot be solved
     * @author Nini Kao (n10212469)
     */
    private void Pop_unsolvable(){
        JFrame jFrame = new JFrame();
        JOptionPane.showMessageDialog(jFrame,"Maze cannot be solved");
    }

    /**
     * A pop up screen when show optimal is not selected
     * @author Nini Kao (n10212469)
     */
    private void Pop_showbox(){
        JFrame jFrame = new JFrame();
        JOptionPane.showMessageDialog(jFrame,"Show optimal path is not selected");
    }
}
