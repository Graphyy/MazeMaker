// TODO: Editing GUI

package GUI;

import DBUtils.MazeData;
import MazeUtils.MazeDataTypes.Maze;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

/**
 * Abstract class containing methods used by all GUI window classes
 */
public abstract class MazeGUI implements ActionListener, windows, Runnable  {

    JFrame programWindow;

    /**
     * Method to create a JFrame window to display the program with few specifications
     * The window will later be customised by other methods and classes
     * @author Elliott McGrath
     */
    public JFrame createWindow () {
        JFrame window = new JFrame("Maze Maker");
        window.setVisible(true); // Make it so we can see the Jframe
        window.addWindowListener(new WindowAdapter() {  // Program will exit if window is closed via the X
            @Override
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });
        return window;
    }

    /**
     * Open the maze editing interface without a maze initialised
     * @author Elliott McGrath (n9701958)
     */
    public void openBlankMazeEdit() { SwingUtilities.invokeLater(new MazeEdit()); }

    /**
     * Open the maze editing interface with the specified maze loaded into the DrawPanel
     * @param maze The maze object to be edited
     */
    public void openMazeEdit(Maze maze) {SwingUtilities.invokeLater(new MazeEdit().loadMaze(maze));}

    /**
     * Open the maze create window
     */
    public void openMazeCreate(){ SwingUtilities.invokeLater(new MazeCreate()); }

    /**
     * Open the maze export window
     */
    public void openMazeExport() { SwingUtilities.invokeLater(new MazeExport(new MazeData())); }

    /**
     * Open the maze database browser
     */
    public void openMazeDBBrowser() {SwingUtilities.invokeLater(new MazeDBBrowse(new MazeData())); }

    /**
     * Open the landing page interface
     * @author Elliott McGrath (n9701958)
     */
    public void openLandingPage() { SwingUtilities.invokeLater(new GUILandingPage()); }

    /**
     * return the JFrame object of the window currently on screen
     */
    public JFrame returnJFrame() {
        return programWindow;
    }

    /**
     * Dispose of the JFrame object of the window currently on screen
     */
    public void killJFrame() {
        programWindow.dispose();
    }

    /**
     * handles 'action 'events' from Action Listeners
     * Action events occur when a user, for example, presses a button
     * When this happens, an 'actionPerformed' message is sent to the listeners
     * This method therefore defines the behaviour of the program when certain actions occur
     * @param e ActionEvent
     */
    @Override
    public void actionPerformed(ActionEvent e) {

    }

}
