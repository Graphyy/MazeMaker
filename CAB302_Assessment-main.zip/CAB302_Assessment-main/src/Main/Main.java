package Main;

import DBUtils.mazeDataBase;
import GUI.GUILandingPage;

import javax.swing.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

// TODO: Exception handling across project
// TODO: Run code cleanup
public class Main {
    public static void main(String[] args) {

        SwingUtilities.invokeLater(new GUILandingPage());
        GUILandingPage.showWelcomeDialog();
        System.out.println("Started at " + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss")) + " on " + System.getProperty("os.name") + " host.");
        mazeDataBase mazeDB = new mazeDataBase(); // Create new datatype for storing database connection info
    }
}
