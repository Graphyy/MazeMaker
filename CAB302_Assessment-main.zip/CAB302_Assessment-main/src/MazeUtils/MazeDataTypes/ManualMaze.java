package MazeUtils.MazeDataTypes;

import java.io.Serial;
import java.io.Serializable;

/**
 * Class defining object that represents a manually created maze
 */
public class ManualMaze extends Maze implements Serializable{

    @Serial
    private static final long serialVersionUID = 2475223795512288538L;

    /**
     * Creates a new maze with a given name, height, and width, and records the name of its author
     *
     * @param name     The name of the maze
     * @param author   The author of the maze
     * @param height   The height of the maze in square units
     * @param width    The width of the maze in square units
     * @param cellSize The size of the square cells used to construct the maze
     * @param logo     The bufferedImage for the logo to be placed in the maze
     */
    public ManualMaze(String name, String author, int height, int width, int cellSize, Logo logo) throws IllegalArgumentException {
        super(name, author, height, width, cellSize, logo);

        if (this.getLogo() == null) {
            this.cellGrid = new CellGrid(width, height, cellSize, 0);
        } else {
            this.cellGrid = new CellGrid(width, height, cellSize, this.getLogo().getSize());
        }

    }



}
