package MazeUtils.MazeDataTypes;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.*;

/**
 * A special data structure used to store the logo information.
 *  also allows for custom serialisation of the BufferedImage stored within the logo class
 */
public class Logo implements Serializable {

    @Serial
    private static final long serialVersionUID = -8494369131663658869L;

    transient BufferedImage logo;
    final int width;
    final int height;
    final int size;

    /**
     * Class used mainly to store information about the logo and allow for
     * proper serialization of the logo file
     * @param logo Bufferedimage storing logo data
     * @param size Size of the logo (both x and y dimension)
     */
    public Logo (BufferedImage logo, int size) {
        this.logo = logo;
        this.width = logo.getWidth();
        this.height = logo.getHeight();
        this.size = size;
    }

    /**
     * Returns BufferedImage object stored within this logo class
     * @return BufferedImage object stored within this logo class
     */
    public BufferedImage getBufferedImg() {
        return logo;
    }

    /**
     * Sets BufferedImage object stored within this logo class
     * @param img Sets BufferedImage object stored within this logo class
     */
    public void setBufferedImg(BufferedImage img) {
        logo = img;
    }

    /**
     * Returns size dimensions of square logo according to the number of cells it occupies
     * @return dimensions of the square logo according to the number of cells it occupies
     */
    public int getSize() {
        return size;
    }

    /**
     * Custom method used to serialise the logo object properly
     * @param out ObjectOutputStream created to write the image
     * @throws IOException Exception occurs if file cannot be accessed or written
     */
    @Serial
    private void writeObject(ObjectOutputStream out) throws IOException {
        out.defaultWriteObject();
        ImageIO.write(logo, "png", out);
    }

    /**
     * Custom method used to serialise the logo object properly
     * @param in ObjectInputStream created to read the image
     * @throws IOException Exception occurs if file cannot be accessed or read
     * @throws ClassNotFoundException Exception if class file cannot be located
     */
    @Serial
    private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
        in.defaultReadObject();
        logo = ImageIO.read(in);
    }


}
