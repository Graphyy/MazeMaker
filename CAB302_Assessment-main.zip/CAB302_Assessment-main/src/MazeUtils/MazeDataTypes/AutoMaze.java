package MazeUtils.MazeDataTypes;

import java.io.Serial;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Class defining object that represents an automatically generated maze
 * @author Elliott McGrath (n9701958)
 */
public class AutoMaze extends Maze implements Serializable {

    @Serial
    private static final long serialVersionUID = 2145258872694226560L;
    private final int difficulty;

    /**
     * Creates a new maze with a given name, height, and width, and records the name of its author
     *
     * @param name     The name of the maze
     * @param author   The author of the maze
     * @param height   The height of the maze in square units
     * @param width    The width of the maze in square units
     * @param cellSize The size of the square cells used to construct the maze
     * @param logo     Buffered image to be displayed as logo
     * @param difficulty Difficulty of generated maze
     */
    public AutoMaze(String name, String author, int height, int width, int cellSize, int difficulty, Logo logo) throws IllegalArgumentException{
        super(name, author, height, width, cellSize, logo);
        // Theoretically this exception will never be shown, but it's good to have it just in case.
        if (difficulty > 100 || difficulty < 0 || difficulty == ' ') {
            throw new IllegalArgumentException("Illegal difficulty (Must be between 0 and 100)");
        } else {
            this.difficulty = difficulty;
        }
    }

    /**
     * Return the width of the maze (in square units)
     * @return {int} difficulty
     */
    public int getDifficulty() {
        return difficulty;
    }

    /**
     * Generate Maze automatically according to the difficulty set by the user
     * @param maze MAze object to generate cell grid for
     * @return generated cellGrid
     * @author Elliott McGrath (n9701958)
     */
    @SuppressWarnings("ConstantConditions")
    public CellGrid generateMaze(Maze maze){

        // Get some basic information about the maze
        int gridX = maze.getWidth();
        int gridY = maze.getHeight();
        int cellSize = maze.getCellSize();

        // Create a new blank CellGrid for the maze
        if (maze.getLogo() == null) {
            cellGrid = new CellGrid(gridX, gridY, cellSize, 0);
        } else {
            cellGrid = new CellGrid(gridX, gridY, cellSize, maze.getLogo().getSize());
        }

        // Get the coordinates and cellRef for the first cell
        Cell origin = cellGrid.getCell(1, 1);
        int[] coordinates = origin.getCoords();
        coordinates = convertCoords(coordinates, cellSize);
        int startRef = getCellRef(coordinates, gridX);

        // Set up variables for random walk
        int nextStep;
        List<Integer> possibleMoves;
        List<Integer> visitedCells = new ArrayList<>();

        // Add the logo coordinates to visited so the maze algorithm ignores it
        int noOfLogoCells = 0;
        for (int [] i: cellGrid.getLogoCoords()) {
            int ref =  getCellRef(i, gridX);
            visitedCells.add(ref);
            noOfLogoCells++;
        }

        // Add the start cell after the logo coords to avoid backtracing into the logo area
        visitedCells.add(startRef);

        for (int i = 1; i < ((gridX - 2) * (gridY - 2)); i++) {

            String direction = null;
            possibleMoves = calcPossibleMoves(coordinates, gridX, gridY, cellGrid, visitedCells);

            boolean movePossible = false;

            for (Integer possibleMove : possibleMoves) {
                if (possibleMove != -1) {
                    movePossible = true;
                    break;
                }
            }

            nextStep = pickRandomMove(possibleMoves);

            if(!movePossible) {
                int len = visitedCells.size();
                for (int l = len - 1 - noOfLogoCells; l >= 0; l--) {
                    if (movePossible) {
                        break;
                    }
                    //int d = visitedCells.get(l);
                    int[] cellCoords = getCellCoords(visitedCells.get(l), gridX);
                    possibleMoves = calcPossibleMoves(cellCoords, gridX, gridY, cellGrid, visitedCells);
                    nextStep = pickRandomMove(possibleMoves);
                    coordinates = getCellCoords(visitedCells.get(l), gridX);
                    for (int x: possibleMoves) {
                        if (x != -1) {
                            movePossible = true;
                            break;
                        }
                    }
                }
            }

            if (nextStep == 0) {
                direction = "UP";
            } else if (nextStep == 1) {
                direction = "DOWN";
            } else if (nextStep == 2) {
                direction = "LEFT";
            } else if (nextStep == 3) {
                direction = "RIGHT";
            }

            try {
                cellGrid.toggleWall(coordinates[0], coordinates[1], cellGrid, direction);
            } catch (Exception e){
                break;
            }

            visitedCells.add(possibleMoves.get(nextStep));

            coordinates = getCellCoords(possibleMoves.get(nextStep), gridX);

        }

        return cellGrid;
    }

    /**
     * Convert coordinates from format used by graphics package to that utilised by CellGrid.
     * @param coordinates Coordinates in graphics package format
     * @param cellSize Size of each cell in the maze in pixels
     * @return Array containing coordinates in CellGrid format
     */
    public int[] convertCoords(int [] coordinates, int cellSize) {
        int x = coordinates[0] / cellSize;
        int y = coordinates[1] / cellSize;
        return new int[] {x,y};
    }

    /**
     * Pick a random movement from the list of possible movements
     * @param possibleMoves List of possible movements
     * @return Chosen random movement
     */
    public int pickRandomMove(List<Integer> possibleMoves) {
        boolean movePossible = false;
        Random random = new Random();
        int index = -1;
        int size = possibleMoves.size();


        for (Integer possibleMove : possibleMoves) {
            if (possibleMove != -1) {
                movePossible = true;
                break;
            }
        }

        if (movePossible) {
            for (int i = 0; i <= size; i++) {
                index = random.nextInt(size);
                if (possibleMoves.get(index) == -1) {
                    i--;
                } else {
                    break;
                }
            }
        } else {
            return -1;
        }

        return index;

    }

    /**
     * gets the cell ‘reference’, which is simply an alternative
     * coordinate system that uses one integer value instead of two.
     * The numbering of the cells is left to right, top to bottom,
     * so if we have a 12x12 grid; we will have 144 individually numbered squares.
     * @param coords Coordinates in format used by CellGrid
     * @param gridX Horizontal size of the maze in number of cells
     * @return A cell reference pointing to the same cell referenced by the coordinates when they were in CellGrid format
     */
    public int getCellRef(int [] coords, int gridX) {
        int x = coords[0];
        int y = coords[1];
        return (y-1) * (gridX - 2) + x;
    }

    /**
     * Method to convert a cell ‘reference’ back into the coordinate system used by CellGrid.
     * @param cellRef The cell reference of the cell we want the coordinates of
     * @param gridX Horizontal size of the maze in number of cells
     * @return Coordinates for cell reference in CellGrid format
     */
    public int[] getCellCoords(int cellRef, int gridX) {
        int x,y;

        y = (int)Math.ceil((float)cellRef / (float)(gridX - 2)); // Fix integer division issue
        x = cellRef - ((gridX - 2) * (y - 1));

        return new int [] {x,y};
    }

    /**
     *  Calculates the possible moves for the maze generation
     *  algorithm based the current cell coordinates, excluding
     *  cells which have been previously visited.
     * @param coords        Current co-ordinates
     * @param gridX         Size of the grid (X)
     * @param gridY         Size of the grid (Y)
     * @param grid          Cell grid data
     * @param visitedCells  List of previously visited cells
     * @return  List of possible moves
     * @author Elliott McGrath (n9701958)
     */
    public List<Integer> calcPossibleMoves (int [] coords, int gridX, int gridY, CellGrid grid, List<Integer> visitedCells) {

        List<Integer> possibleMoves = new ArrayList<>();
        int topWall, bottomWall, leftWall, rightWall;

        topWall = checkWall(coords, grid, "TOP", gridX, gridY);
        bottomWall = checkWall(coords, grid, "BOTTOM", gridX, gridY);
        leftWall = checkWall(coords, grid, "LEFT", gridX, gridY);
        rightWall = checkWall(coords, grid, "RIGHT", gridX, gridY);

        if(visitedCells.contains(topWall)) {
            topWall = -1;
        }

        if(visitedCells.contains(bottomWall)) {
            bottomWall = -1;
        }

        if(visitedCells.contains(leftWall)) {
            leftWall = -1;
        }

        if(visitedCells.contains(rightWall)) {
            rightWall = -1;
        }

        possibleMoves.add(topWall);
        possibleMoves.add(bottomWall);
        possibleMoves.add(leftWall);
        possibleMoves.add(rightWall);

        return possibleMoves;
    }


    /**
     * Check the state of one of the walls around a cell.
     * @param coords Coordinates of the cell (cellGrid format)
     * @param grid Cellgrid Object containing the cells of interest
     * @param side Which direction of wall to check
     * @param gridX Horizontal size of the grid
     * @param gridY Vertical size of the grid
     * @return Cell reference value indicating the coordinates of the cell if the wall is not present or -1 if the wall is present
     * @author Elliott McGrath (n9701958)
     */
    int checkWall(int [] coords, CellGrid grid, String side, int gridX, int gridY) {

        int x,y;

        if (side.equals("TOP") && coords[1] > 1) {
            x = coords[0];
            y = coords[1] - 1;
        } else if (side.equals("BOTTOM") && coords[1] < (gridY - 2)) {
            x = coords[0];
            y = coords[1] + 1;
        } else if (side.equals("LEFT") && coords[0] > 1) {
            x = coords[0] - 1;
            y = coords[1];
        } else if (side.equals("RIGHT") && coords[0] < (gridX - 2)) {
            x = coords[0] + 1;
            y = coords[1];
        } else {
            return -1;
        }


        try {
            grid.getCell(x,y);
            int [] theCell = {x, y};
            return getCellRef(theCell, gridX);
        } catch (Exception e) {
            return -1;
        }
    }

}


