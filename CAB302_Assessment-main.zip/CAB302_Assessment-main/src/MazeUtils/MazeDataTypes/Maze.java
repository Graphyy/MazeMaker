package MazeUtils.MazeDataTypes;

import java.io.*;
import java.time.LocalDateTime;

/**
 * The class establishing the fundamental characteristics of the "Maze" data structure
 * Automaze and ManualMaze are children of the Maze class
 */
public class Maze implements Serializable {

    @Serial
    private static final long serialVersionUID = -1129740336325338865L;

    private String name, author;
    private int id, height, width, cellSize;
    private LocalDateTime createdTime;
    private LocalDateTime lastEditTime;
    CellGrid cellGrid;
    Logo logo;

    /**
     * Creates a new maze with a given name, height, and width, and records the name of its author
     * @param name The name of the maze
     * @param author The author of the maze
     * @param height The height of the maze in square units
     * @param width The width of the maze in square units
     * @param cellSize The size of the square cells used to construct the maze
     * @param logo Buffered logo image to be displayed in the maze
     */
    public Maze(String name, String author, int height, int width, int cellSize, Logo logo) throws IllegalArgumentException {

        this.logo = logo;

        if(name.isBlank())
            throw new IllegalArgumentException("Maze title cannot be empty!");
        else
            this.name = name;
        if(author.isBlank())
            throw new IllegalArgumentException("Maze author cannot be empty!");
        else
            this.author = author;
        if(cellSize <= 0 || cellSize == ' ')
            throw new IllegalArgumentException("Illegal cell size (Must be at least 1)");
        else if (cellSize > 50)
            throw new IllegalArgumentException("Illegal cell size (Must be at most 50)");
        else
            this.cellSize = cellSize;

        // Spec says height and width should not exceed 100, so we'll except if it does.
        // Both of these values have 2 added to them for the purpose of adding details around the edge of the maze. These checks will check if the actual maze part is legal.
        if (height - 2 > 100) {
            throw new IllegalArgumentException("Illegal height (Must be below 100)");
        } else if (height - 2 < 1) {
            throw new IllegalArgumentException("Illegal height (Must be at least 1)");
        } else if(height == ' '){
            throw new IllegalArgumentException("Height cannot be empty!");
        }
        else {
            this.height = height;
        }
        if (width - 2 > 100) {
            throw new IllegalArgumentException("Illegal width (Must be below 100)");
        } else if (width - 2 < 1) {
            throw new IllegalArgumentException("Illegal width (Must be at least 1)");
        } else if (width == ' '){
            throw new IllegalArgumentException("Width cannot be empty!");
        }
        else {
            this.width = width;
        }
        createdTime = LocalDateTime.now();
        lastEditTime = createdTime; // Since it was just created, we can assume it was last edited now.
    }

    /**
     * No args constructor.
     */
    public Maze() {
        logo = null;
    }

    /**
     * Method used to customise the serailisation process for the maze object
     * @return A byte array representing the maze object and child fields stored within it
     * @throws IOException Throws exception if serialisation process fails
     */
    public byte[] getOutputStream() throws IOException {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        ObjectOutputStream oos = new ObjectOutputStream(bos);
        oos.writeObject(this);

        return bos.toByteArray();
    }

    /**
     * Return the database ID of the maze object
     * @return the database ID of the maze object
     */
    public int getId(){return  id;}

    /**
     * Set the database ID of the maze object
     * @param id the database ID we want to assign to the maze object
     */
    public void setId(int id){this.id = id;}

    /**
     * Get the CellGrid object stored within the maze object
     * @return the CellGrid object stored within the maze object
     */
    public CellGrid getCellGrid() {return cellGrid;}

    /**
     * Set the CellGrid object stored within the maze object
     * @param grid the CellGrid object to store within the maze object
     */
    public void setCellGrid(CellGrid grid) { this.cellGrid = grid; }

    /**
     * Get the logo object stored within the maze object
     * @return the logo object stored within the maze object
     */
    public Logo getLogo() {
        return logo;
    }

    /**
     * Set the logo object stored within the maze object
     * @param logo the logo object to store within the maze object
     */
    public void setLogo(Logo logo) {
        this.logo = logo;
    }

    /**
     * Return the name of the maze (in string)
     * @return {String} name
     */
    public String getName() {
        return name;
    }

    /**
     * Set the name of the maze (in string)
     * @param name {String} name
     */
    public void setName(String name) {
        if (name.equals("")) {
            throw new IllegalArgumentException("Maze title cannot be empty!");
        } else {
            this.name = name;
        }

    }

    /**
     * Return the author of the maze (in string)
     * @return {String} author
     */
    public String getAuthor() {
        return author;
    }

    /**
     * Set the author of the maze (in string)
     * @param author {String} author
     */
    public void setAuthor(String author) {
        if (author.equals("")) {
            throw new IllegalArgumentException("Maze author cannot be empty!");
        } else {
            this.author = author;
        }
    }

    /**
     * Return the height of the maze (in square units)
     * @return {int} height
     */
    public int getHeight() {
        return height;
    }

    /**
     * Set the height of the maze (in square units)
     * @param height {int} New height
     */
    public void setHeight(int height) {
        this.height = height;
    }

    /**
     * Return the width of the maze (in square units)
     * @return {int} width
     */
    public int getWidth() {
        return width;
    }

    /**
     * Set the width of the maze (in square units)
     * @param width {int} New height
     */
    public void setWidth(int width) {
        this.width = width;
    }

    /**
     * Return the side length of the square cells
     * @return {int} side length
     */
    public int getCellSize() {
        return cellSize;
    }

    /**
     * Set new cell side length
     * @param cellSize {int} new side length
     */
    public void setCellSize(int cellSize) {
        this.cellSize = cellSize;
    }

    /**
     * Return the date and time when Maze is created
     * @return {LocalDateTime} createdTime
     */
    public LocalDateTime getCreateTime(){return this.createdTime;}

    /**
     * Return the date and time when Maze is last edited
     * @return {LocalDateTime} lastEditTime
     */
    public LocalDateTime getLastEditTime(){return this.lastEditTime;}

    /**
     * Set the last edit time to a specific time
     * @param time {LocalDateTime} the last time the maze was edited (Cannot be before the maze was created).
     */
    public  void  setLastEditTime(LocalDateTime time) {
        if (time.isBefore(this.getCreateTime())){
            throw new IllegalArgumentException("Cannot be edited before creation time");
        } else if (time.isBefore(this.getLastEditTime())) {
            throw new IllegalArgumentException("Cannot be edited before last edit time");
        } else {
            lastEditTime = time;
        }
    }

    /**
     * Set the last edit time to LocalDateTime.now()
     */
    public void setLastEditTime() {
        lastEditTime = LocalDateTime.now();
    }
}
