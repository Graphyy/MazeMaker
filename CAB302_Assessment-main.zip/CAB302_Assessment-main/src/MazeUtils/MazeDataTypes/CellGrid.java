package MazeUtils.MazeDataTypes;

import java.io.Serial;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Random;

/**
 * Abstract data type created to organise Cell objects into a 2-dimensional grid. <br/>
 * The purpose of placing cells into a 2D grid is to enable us to iterate through
 * the grid with <b>for</b> loops that will render each cell individually. <br/>
 * @author Elliott McGrath (n9701958)
 */
public class CellGrid implements Serializable {

    @Serial
    private static final long serialVersionUID = -8494369181663658869L;

    private final ArrayList<ArrayList<Cell>> cellGrid;
    private final int gridX;
    private final int gridY;
    private final int cellSize;

    public String[] entryCell = new String[3];
    public String[] exitCell = new String[3];

    private final ArrayList<int[]> logoCoords = new ArrayList<>();

    /**
     * To construct a CellGrid we must provide the maze's dimensions via <i>gridX and gridY</i> integers. <br/>
     * The size of each cell in the grid must also be given by <i>cellSize</i>
     * @param gridX The horizontal position of the cell in the maze
     * @param gridY The vertical position of the cell in the maze
     * @param cellSize The size of each square cell in the maze
     */
    public CellGrid(int gridX, int gridY, int cellSize, int logoSize) {

        // Set the private variables for this class
        this.gridX = gridX;
        this.gridY = gridY;
        this.cellSize = cellSize;

        // Initialise the cellGrid as an ArrayList
        cellGrid = new ArrayList<>();

        // Add rows to the two-dimensional grid
        for (int i = 0; i < Math.max(gridX, gridY); i++) {
            cellGrid.add(new ArrayList<>());
        }

        // Add new cells to the grid
        for(int x = 0; x < gridX; x++) {
            for(int y = 0; y < gridY; y++) {
                cellGrid.get(x).add(new Cell(x * cellSize, y * cellSize));
            }
        }

        Random random = new Random();
        int topLeftX = random.nextInt((gridX - 3));
        int topLeftY = random.nextInt((gridY - 3));

        while (topLeftX + logoSize > (gridX - 3) || topLeftX < 2) {
            topLeftX = random.nextInt((gridX - 3));
        }

        while (topLeftY + logoSize > (gridY - 3) || topLeftY < 2) {
            topLeftY = random.nextInt((gridY - 3));
        }

        setLogoCoords(logoSize, topLeftX, topLeftY);

        clearOuterLayer();  // Make the outer layer of cells in the grid invisible

        setEntryExitCell(1, 1, "Entry");
        setEntryExitCell(gridX - 2, gridY - 2, "Exit");
    }

    /**
     * Method to remove or add walls to a cell. ‘int x, int y’ indicates the x and y coordinates of the cell.
     * Possible values for String direction are: UP, DOWN, LEFT, RIGHT.
     * 'UP' indicating removal of top wall, 'LEFT' indicating removal of left wall etc.
     * @param x The horizontal position of the cell (in the CellGrid) to be edited
     * @param y The vertical position of the cell (in the CellGrid) to be edited
     * @param cells The cellgrid object whose cells are to be modified
     * @param direction The direction of the wall to be toggled on or off
     */
    public void toggleWall(int x, int y, CellGrid cells, String direction)  {

        if(direction.equals("UP")) {
            if (cells.getCell(x, y).topWall){
                cells.getCell(x, y).setAnyWall(false, direction);
                cells.getCell(x, y - 1).setAnyWall(false, "DOWN");
            } else {
                cells.getCell(x, y).setAnyWall(true, direction);
                cells.getCell(x, y - 1).setAnyWall(true, "DOWN");
            }
        }
        if(direction.equals("DOWN")) {
            if (cells.getCell(x, y).bottomWall){
                cells.getCell(x ,y ).setAnyWall(false, direction);
                cells.getCell(x , y + 1 ).setAnyWall(false, "UP");
            } else {
                cells.getCell(x ,y ).setAnyWall(true, direction);
                cells.getCell(x , y + 1 ).setAnyWall(true, "UP");
            }
        }

        if(direction.equals("LEFT")) {
            if (cells.getCell(x, y).leftWall){
                cells.getCell(x, y).setAnyWall(false, direction);
                cells.getCell(x - 1, y).setAnyWall(false, "RIGHT");
            } else {
                cells.getCell(x, y).setAnyWall(true, direction);
                cells.getCell(x - 1, y).setAnyWall(true, "RIGHT");
            }

        }

        if(direction.equals("RIGHT")) {
            if (cells.getCell(x, y).rightWall){
                cells.getCell(x, y).setAnyWall(false, direction);
                cells.getCell(x + 1, y).setAnyWall(false, "LEFT");
            } else {
                cells.getCell(x, y).setAnyWall(true, direction);
                cells.getCell(x + 1, y).setAnyWall(true, "LEFT");
            }

        }

    }

    /**
     * Set the x and y coordinates of either the entry or exit cell
     * @param x Horizontal position of the entry/exit cell
     * @param y Vertical position of the entry/exit cell
     * @param entryExit String indicating if the entry or exit cell is to be set
     */
    public void setEntryExitCell(int x, int y, String entryExit) {
        if(entryExit.equals("Entry")) {
            entryCell[0] = String.valueOf(x);
            entryCell[1] = String.valueOf(y);
            cellGrid.get(x).get(y).setAnyWall(false, "UP");
        } else if (entryExit.equals("Exit")) {
            exitCell[0] = String.valueOf(x);
            exitCell[1] = String.valueOf(y);
            cellGrid.get(x).get(y).setAnyWall(false, "DOWN");
        }
    }

    /**
     * Returns a list containing all logo coordinates.
     * @return an ArrayList containing all logo coordinates.
     */
    public ArrayList<int[]> getLogoCoords(){
        return logoCoords;
    }

    /**
     * Method that sets new coordinates for Logo image.
     * Variables topLeftX and topLeftY indicatecoordinates for the logo,
     * and xy indicates
     * @param xy The size of the square logo in number of cells it occupies.
     * @param topLeftX Horizontal position of the top left corner cell where the logo will be placed
     * @param topLeftY Vertical position of the top left corner cell where the logo will be placed
     */
    public void setLogoCoords(int xy, int topLeftX, int topLeftY) {
        if (logoCoords.isEmpty()) {
            for (int x = 0; x < xy; x++) {
                for (int y = 0; y < xy; y++) {
                    logoCoords.add(new int[]{(topLeftX + x), (topLeftY + y)});
                }
            }
        } else {
            logoCoords.clear();
            for (int x = 0; x < xy; x++) {
                for (int y = 0; y < xy; y++) {
                    logoCoords.add(new int[]{(topLeftX + x), (topLeftY + y)});
                }
            }
        }

    }


    /**
     * Getter method used to return a single cell object at the specified dimension.
     * @param x The X coordinate of the Cell to be returned
     * @param y The Y coordinate of the Cell to be returned
     * @return A <i>Cell</i> object that exists at the specified X and Y coordinates.
     * @author Elliott McGrath (n9701958)
     */
    public Cell getCell(int x, int y) {
        return cellGrid.get(x).get(y);
    }


    /**
     * Method to make the outer layer of cells in the maze invisible. <br/>
     * The purpose of having the outer layer invisible is that we can
     * add other elements such as directional arrows just outside the maze's borders.
     * @author Elliott McGrath (n9701958)
     */
    private void clearOuterLayer() {
        clearColumn(0);
        clearRow(0);
        clearColumn(gridX - 1);
        clearRow(gridY - 1);
    }

    /**
     * Helper method for clearOuterLayer that only clears a single specified column in the grid.
     * @param column the index position of the column to be cleared
     * @author Elliott McGrath (n9701958)
     */
    private void clearColumn(int column) {
        for (int i = 0; i < gridY; i++) {
            cellGrid.get(column).get(i).setAnyWall(false, "DOWN");
            cellGrid.get(column).get(i).setAnyWall(false, "UP");
            cellGrid.get(column).get(i).setAnyWall(false, "LEFT");
            cellGrid.get(column).get(i).setAnyWall(false, "RIGHT");
        }
    }

    /**
     * Helper method for clearOuterLayer that only clears a single specified row in the grid.
     * @param row the index position of the row to be cleared
     * @author Elliott McGrath (n9701958)
     */
    private void clearRow(int row) {
        for (int i = 0; i < gridX; i++) {
            cellGrid.get(i).get(row).setAnyWall(false, "DOWN");
            cellGrid.get(i).get(row).setAnyWall(false, "UP");
            cellGrid.get(i).get(row).setAnyWall(false, "LEFT");
            cellGrid.get(i).get(row).setAnyWall(false, "RIGHT");
        }
    }

    /**
     * Return the size of the square cells in the maze in pixels
     * @return the size of the square cells in the maze in pixels
     */
    public int getCellSize() {
        return cellSize;
    }
}
