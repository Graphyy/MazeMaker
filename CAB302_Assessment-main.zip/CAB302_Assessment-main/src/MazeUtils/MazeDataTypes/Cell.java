package MazeUtils.MazeDataTypes;

import java.io.*;

/**
 * <p>
 * Abstract data type representing a single 2d cell to be rendered by DrawPanel. <br/>
 * Cells are used by the Graphics package to represent what will be drawn on the MazeEdit screen.<br/>
 * Each cell is a 2-dimensional square; with its X and Y coordinates being defined upon initialisation. <br/>
 * Every cell has four boolean fields that indicate the visibility of the top, bottom, left and right walls.</p>
 *
 * <p>
 * If one of these boolean values is false, that wall will not be rendered <br/>
 * For example: if we want two adjacent cells to be joined together, we must: <br/>
 * 1. Disable the right wall of the left cell <br/>
 * 2. Disable the left wall of the right cell <br/>
 *
 * @author Elliott McGrath (n9701958)
 */
public final class Cell implements Serializable, Externalizable {

    @Serial
    private static final long serialVersionUID = 4390482518182625971L;

    private int xPos;
    private int yPos;
    /** A <i>true</i> value indicates that this side of the cell border will be rendered */
    public boolean topWall, bottomWall, leftWall, rightWall;


    /**
     * <p>Constructor for Cell objects:</p>
     * Each cell is square, the size of which is defined by variable cellSize upon initialisation.<br/>
     * Each cell has an X and a Y coordinate which is set according to xPos and yPos when a cell is initialised.<br/>
     * @param xPos The horizontal position of the cell in the maze
     * @param yPos The vertical position of the cell in the maze
     * @author Elliott McGrath (n9701958)
     */

    public Cell(int xPos, int yPos) {
        this.xPos = xPos;
        this.yPos = yPos;
        this.topWall = true;
        this.bottomWall = true;
        this.leftWall = true;
        this.rightWall = true;
    }


    /**
     * Empty constructor used so that Cell objects can be serialized
     * by file
     */
    public Cell() {

    }


    /**
     * Return the horizontal position of the Cell in the CellGrid
     * @return the horizontal position of the Cell in the CellGrid
     */
    public int getXPos() {
        return xPos;
    }

    /**
     * Return the vertical position of the Cell in the CellGrid
     * @return the vertical position of the Cell in the CellGrid
     */
    public int getYPos() {
        return yPos;
    }

    /**
     * Set the horizontal and vertical position of the Cell in the CellGrid
     * @param newX the new horizontal position of the Cell in the CellGrid
     * @param newY the new vertical position of the Cell in the CellGrid
     */
    public void setXYPos(int newX, int newY) {
        this.xPos = newX;
        this.yPos = newY;
    }

    /**
     * Return the vertical and Horizontal position of the Cell in the CellGrid
     * @return the vertical and Horizontal position of the Cell in the CellGrid
     */
    public int[] getCoords() {
        return new int[]{this.xPos, this.yPos};
    }

    /**
     * Method to return the boolean state of any of the four walls bordering a cell
     * @param direction The wall direction to query
     * @return The boolean state of the wall (True = Up, False = down)
     */
    public boolean getAnyWall(String direction) {
        return switch (direction) {
            case "UP" -> topWall;
            case "DOWN" -> bottomWall;
            case "LEFT" -> leftWall;
            case "RIGHT" -> rightWall;
            default -> false;
        };
    }

    /**
     * Method to set the Boolean state of the four walls of the cell
     * @param value The value to assign to that wall (True = Up, False = down)
     * @param direction The direction of the wall to be set
     */
    public void setAnyWall(boolean value, String direction) {
        switch (direction) {
            case "UP" -> this.topWall = value;
            case "DOWN" -> this.bottomWall = value;
            case "LEFT" -> this.leftWall = value;
            case "RIGHT" -> this.rightWall = value;
            default -> {
            }
        }
    }

    /**
     * Methods to customise the serialisation process for cells
     * @param out ObjectOutput object used by external ProxyRef class
     * @throws IOException Exception thrown when serialisation process fails
     */
    @Override
    public void writeExternal(ObjectOutput out) throws IOException {
        out.writeInt(xPos);
        out.writeInt(yPos);
        out.writeBoolean(topWall);
        out.writeBoolean(bottomWall);
        out.writeBoolean(leftWall);
        out.writeBoolean(rightWall);
    }

    /**
     * Methods to customise the serialisation process for cells
     * @param in ObjectInput object used by external ProxyRef class
     * @throws IOException Exception thrown when serialisation process fails
     */
    @Override
    public void readExternal(ObjectInput in) throws IOException {
        this.xPos = in.readInt();
        this.yPos = in.readInt();
        this.topWall = in.readBoolean();
        this.bottomWall = in.readBoolean();
        this.leftWall = in.readBoolean();
        this.rightWall = in.readBoolean();
    }
}
