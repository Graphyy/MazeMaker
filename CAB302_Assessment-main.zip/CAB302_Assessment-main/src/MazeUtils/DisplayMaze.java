package MazeUtils;

import GUI.Graphics.DrawPanel;
import GUI.Graphics.MarkerGrid;
import MazeUtils.MazeDataTypes.CellGrid;
import MazeUtils.MazeDataTypes.Logo;
import MazeUtils.MazeDataTypes.Maze;

import java.awt.*;

/**
 * A method that prepares mazes to be shown in preview windows and for export
 */
public class DisplayMaze {
    private final CellGrid cellGrid;
    private final int gridX,gridY;
    private int cellSize;
    DrawPanel drawPanel;
    Logo logo;


    public DisplayMaze(Maze maze){
        this.cellGrid = maze.getCellGrid();
        this.gridX = maze.getWidth();
        this.gridY = maze.getHeight();
        this.cellSize = maze.getCellSize();
        this.logo = maze.getLogo();

        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();

        int originalCellSize = cellSize;

        while (screenSize.width < (gridX * cellSize) + 100 || screenSize.height < (gridY * cellSize) + 100) {
            cellSize = cellSize - 1;
        }

        for (int x = 0; x < gridX; x++) {
            for (int y = 0; y < gridY; y++) {
                int x2 = (cellGrid.getCell(x, y).getXPos() / originalCellSize) * cellSize;
                int y2 = (cellGrid.getCell(x, y).getYPos() / originalCellSize) * cellSize;
                cellGrid.getCell(x,y).setXYPos(x2, y2);
            }
        }

        maze.setCellSize(cellSize);
    }

    /**
     * Setter method to create a new DrawPanel using global variables stored inside this class.
     * @return A DrawPanel Object to be passed to setupDrawPanel
     */
    public DrawPanel initialiseGUIObjects() {
        // Create a draw panel to render 2d graphics
        this.drawPanel = setupDrawPanel(this.gridX, this.gridY, this.cellSize);
        this.drawPanel.drawLegend = !drawPanel.drawLegend;
        return drawPanel;
    }

    /**
     * Method to setup a drawPanel object for the maze preview windows
     * @param gridX Horizontal dimension of the cellGrid to preview
     * @param gridY Vertical dimension of the cellGrid to preview
     * @param cellSize Size of the individual square cells that make up the CellGrid
     * @return A drawpanel object used to render the maze preview
     */
    public DrawPanel setupDrawPanel(int gridX, int gridY, int cellSize) {
        DrawPanel aDrawPanel = new DrawPanel(null, cellGrid, gridX, gridY, cellSize, logo);
        aDrawPanel.setPreferredSize(new Dimension(gridX * cellSize,gridY * cellSize));
        aDrawPanel.setFocusable(true);
        return aDrawPanel;
    }

}
