// TODO: Iterative maze solving algorithm
// TODO: Link into GUI/MazeEdit.java

package MazeUtils;

import MazeUtils.MazeDataTypes.Cell;
import MazeUtils.MazeDataTypes.CellGrid;
import MazeUtils.MazeDataTypes.Maze;

import javax.swing.*;
import java.awt.*;
import java.util.List;
import java.util.*;

/**
 * A class to solve a maze by using Depth First Search
 */
public class MazeSolver {
    private final Maze maze;
    private final CellGrid cellGrid;
    private final Graphics g;
    private final Cell start;
    private final Cell end;
    private Map<Integer, Cell> reverse_cellDict;
    private Map<Cell, Integer> cellDict;
    private final LinkedList<LinkedList<Cell>> adj= new LinkedList<>();
    private final Set<Cell> visited= new HashSet<>();
    private final int cellSize;

    public MazeSolver(Maze maze, CellGrid cellGrid, Graphics g, Cell start, Cell end, int cellSize){
        this.maze = maze;
        this.cellGrid = cellGrid;
        this.g = g;
        this.start = start;
        this.end = end;
        this.cellSize = cellSize;

        //create cell dictionary and reverse cell dictionary
        solverSetUp();
    }

    /**
     * Create two dictionary that will be used in DFS
     * A DFS graph is created by nested Linked_list. Each node is represented by an integer number.
     * Therefore, a cell dictionary is required to search which cell is representing the node.
     * A reverse cell dictionary is also required to find which node is representing the cell.
     * @author Nini Kao(n10212469)
     */

    public void solverSetUp(){
        //Reverse dictionary: Use cell index to find Cell
        reverse_cellDict = new Hashtable<>();
        int count2 =0;
        for(int i=1;i< maze.getHeight()-1;i++){
            for(int j=1;j<maze.getWidth()-1;j++){
                Cell cell = cellGrid.getCell(j,i);
                reverse_cellDict.put(count2,cell);
                count2 += 1;
            }
        }

        //Dictionary: Use Cell to find cell index
        cellDict = new Hashtable<>();
        int count =0;
        for(int i=1;i< maze.getHeight()-1;i++){
            for(int j=1;j<maze.getWidth()-1;j++){
                Cell cell = cellGrid.getCell(j,i);
                cellDict.put(cell,count);
                count += 1;
            }
        }

        //A graph
        for(int i = 1; i< maze.getHeight()-1;i++){
            for(int j = 1; j< maze.getWidth()-1;j++){
                adj.add(new LinkedList<>(){});
            }
        }
    }

    /**
     * DFS method that find the optimal path to solve the maze.
     * If solvable, a path will be drawn onto the maze.
     * If unsolvable, a pop_up screen will appear to give maze unsolvable warnings
     * @return A list of cell that shows the optimal path from entry to exit
     * @author Nini Kao(n10212469)
     */
    public List<Cell> DFS(){
        boolean isSolvable = false;

        //Create a DFS graph
        Stack<Cell> stack = new Stack<>();
        Cell cell = start;
        stack.push(cell);

        //Dictionary that stores node that have been visited
        visited.add(start);

        //visited all the cell
        while (!stack.isEmpty()){
            cell = stack.pop();
            int index = calculateIndex(cell);
            if(cell == end){
                isSolvable = true;
                break;
            }
            else{
                // Find next steps
                List<Cell> find_possible_cells = findNext(cell);
                for (Cell item : find_possible_cells) {
                    if (!(visited.contains(item))) {
                        adj.get(index).add(item);
                        visited.add(item);
                        stack.push(item);
                    }
                }

            }
        }
        if(isSolvable){
            //find optimal_path
            List<Integer> optimal_path = findOptimalPath(adj,end);

            //convert int to cell
            List<Cell> cell_path = new ArrayList<>();
            for(Integer index: optimal_path){
                Cell cell2 = calculateCell(index);
                cell_path.add(cell2);
            }

            return cell_path;
        }
        else{
            Pop();
            return null;
        }
    }

    /**
     * Draw maze solution path on to the maze
     * @param path The optimal path of the maze found by DFS
     * @author Nini Kao (n10212469)
     */
    public void drawPath(List<Cell> path){
        //draw path
        for(Cell item:path) {
            int[]coords = item.getCoords();
            g.drawRect(coords[0]+6, coords[1]+6, cellSize - 12, cellSize - 12);
            g.setColor(Color.PINK);
            g.fillRect(coords[0]+6, coords[1]+6, cellSize -12, cellSize - 12);
        }
    }

    /**
     * Find all possible neighbours of the cell
     * @param cell Current cell
     * @return A list of neighbour cells
     * @author Nini Kao(n10212469)
     */
    public List<Cell> findNext(Cell cell){
        List<Cell> possible_move = new ArrayList<>();
        //from start
        if(!cell.rightWall){
            int[] coords = cell.getCoords();
            int x = coords[0]/cellSize;
            int y = coords[1]/cellSize;
            //move right
            if(x+1 != 0){
                Cell newcell = cellGrid.getCell(x+1,y);
                possible_move.add(newcell);
            }
        }
        if(!cell.leftWall){
            int[] coords = cell.getCoords();
            int x = coords[0]/cellSize;
            int y = coords[1]/cellSize;
            //move left
            if(x-1 !=0){
                Cell newcell = cellGrid.getCell(x-1,y);
                possible_move.add(newcell);
            }
        }
        if(!cell.topWall){
            int[] coords = cell.getCoords();
            int x = coords[0]/cellSize;
            int y = coords[1]/cellSize;
            //move up
            if(y-1 !=0) {
                Cell newcell = cellGrid.getCell(x, y - 1);
                possible_move.add(newcell);
            }
        }
        if(!cell.bottomWall){
            int[] coords = cell.getCoords();
            int x = coords[0]/cellSize;
            int y = coords[1]/cellSize;
            //move down
            if(y+1 !=0){
                Cell newcell = cellGrid.getCell(x,y+1);
                possible_move.add(newcell);
            }
        }
        return possible_move;

    }

    /**
     * Find Node number to the corresponding Cell from the DFS graph
     * @param cell Current cell
     * @return The corresponding index in the cell Dictionary
     * @author Nini Kao(n10212469)
     */
    public int calculateIndex(Cell cell){
        return cellDict.get(cell);
    }

    /**
     * Find Cell to the corresponding node index from the DFS graph
     * @param adj_index The index of the node in graph that represents the cell
     * @return The corresponding cell in the reverse cell Dictionary
     * @author Nini Kao(n10212469)
     */
    public Cell calculateCell(int adj_index){
        return reverse_cellDict.get(adj_index);
    }

    /**
     * Find the optimal path from the start cell to end cell from the DFS graph
     * @param adj The DFS graph
     * @param cell Exit cell
     * @return A list of node indexes from start node to end node
     * @author Nini Kao(n10212469)
     */
    public List<Integer> findOptimalPath(LinkedList<LinkedList<Cell>> adj, Cell cell){
        List<Integer> path = new ArrayList<>();
        int endindex = calculateIndex(end);
        path.add(endindex);
        Cell current = cell;
        while(current != start){
            for(int i =0;i<adj.size();i++){
                for(Cell item: adj.get(i)){
                    if(item == current){
                        path.add(i);
                        current = calculateCell(i);
                    }
                }
            }
        }
        return path;
    }

    /**
     * A pop up frame when maze is unsolvable
     * @author Nini Kao(n10212469)
     */
    public void Pop(){
        JFrame jFrame = new JFrame();
        JOptionPane.showMessageDialog(jFrame,"Maze cannot be solved");
    }

    /**
     * A method that calculate the percentage of cells
     * are searched to reach the optimal path
     * @return percentage value
     * @author Nini Kao(n10212469)
     */
    public float PercentageCells(){
        float numberofCellsVisited = visited.size();
        return (numberofCellsVisited/cellDict.size())*100;
    }
}


