package MazeUtils;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

/**
 * A class that allows user to export the maze graphics in the program to an image file
 */
public class ExportMaze {

    /**
     * A method that creates a BufferedImage from a snapshot of the DrawPanel window
     * @param component The Drawpanel Window to create the image from
     * @return A BufferedImage object showing the visible components in the DrawPanel window
     */
    public static BufferedImage getScreenShot(Component component) {
        BufferedImage image = new BufferedImage(component.getWidth(), component.getHeight(), BufferedImage.TYPE_INT_RGB);

        // paints into image's Graphics
        component.paint(image.getGraphics());

        return image;
    }


    /**
     * A method that allows user to have the captured BufferedImage saved to their local computer
     * by selecting a path via the file chooser dialog. All images will be saved as a PNG file.
     * @param component The Drawpanel Window to create the image from
     * @throws IOException Throws exception if image output process fails
     */
    public static void getSaveSnapShot(Component component) throws IOException {
        JFrame parentFrame = new JFrame();
        BufferedImage img = getScreenShot(component);
        // write the captured image as a PNG
        JFileChooser fileChooser= new JFileChooser();
        String currentUsersHomeDir = System.getProperty("user.home");
        fileChooser.setCurrentDirectory(new File(currentUsersHomeDir));
        fileChooser.setDialogTitle("Save maze");
        int userSelection = fileChooser.showSaveDialog(parentFrame);
        if (userSelection == JFileChooser.APPROVE_OPTION) {
            File fileToSave = new File(fileChooser.getSelectedFile() + ".png");
            ImageIO.write(img, "png", fileToSave);
            System.out.println("Save as file: " + fileToSave.getAbsolutePath());
        }
    }
}
