package JUnitTests;

import GUI.MazeCreate;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertThrows;

/**
 * Test suite for GUI and GUI.Graphics
 * @author Jing Xuan Yew (n10426787)
 */
public class GUITestCase {

    // Test MazeCreate
    @Test
    public void EmptyMazeAuthor() {
        MazeCreate maze = new MazeCreate();
        maze.setMazeFieldTest("", "Maze", 10, 10,10, 10);
        assertThrows(IllegalArgumentException.class, () -> maze.createMazeObject("Manual", true));
    }

    @Test
    public void EmptyMazeName(){
        MazeCreate maze = new MazeCreate();
        maze.setMazeFieldTest("Author", " ", 10, 10,10, 10);
        assertThrows(IllegalArgumentException.class, () -> maze.createMazeObject("Auto", true));
    }

    @Test
    public void EmptyMazeDifficulty(){
        MazeCreate maze = new MazeCreate();
        maze.setMazeFieldTest("Author", "Maze", ' ', 10,10, 10);
        assertThrows(IllegalArgumentException.class, () -> maze.createMazeObject("Auto", true));
    }

    @Test
    public void EmptyCellSize(){
        MazeCreate maze = new MazeCreate();
        maze.setMazeFieldTest("Author", "Maze", 10, 10,10, ' ');
        assertThrows(IllegalArgumentException.class, () -> maze.createMazeObject("Manual", true));
    }

    @Test
    public void EmptyMazeWidth(){
        MazeCreate maze = new MazeCreate();
        maze.setMazeFieldTest("Author", "Maze", 10, ' ',10, 10);
        assertThrows(IllegalArgumentException.class, () -> maze.createMazeObject("Manual", true));
    }

    @Test
    public void EmptyMazeHeight(){
        MazeCreate maze = new MazeCreate();
        maze.setMazeFieldTest("Author", "Maze", 10, 10,' ', 10);
        assertThrows(IllegalArgumentException.class, () -> maze.createMazeObject("Manual", true));

    }

    @Test
    public void IllegalMazeWidth(){
        MazeCreate maze = new MazeCreate();
        maze.setMazeFieldTest("Author", "Maze", 10, 150,10, 10);
        assertThrows(IllegalArgumentException.class, () -> maze.createMazeObject("Manual", true));
    }

    @Test
    public void IllegalMazeHeight(){
        MazeCreate maze = new MazeCreate();
        maze.setMazeFieldTest("Author", "Maze", 10, 10,150, 10);
        assertThrows(IllegalArgumentException.class, () -> maze.createMazeObject("Manual", true));
    }

    @Test
    public void IllegalCellSize(){
        MazeCreate maze = new MazeCreate();
        maze.setMazeFieldTest("Author", "Maze", 10, 10,10, -10);
        assertThrows(IllegalArgumentException.class, () -> maze.createMazeObject("Manual", true));

    }

}
