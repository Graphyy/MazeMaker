package JUnitTests;

import DBUtils.mazeDataBase;
import MazeUtils.MazeDataTypes.Maze;
import org.junit.jupiter.api.Test;

import javax.swing.table.DefaultTableModel;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.SQLException;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Testing suite for the DBUtils package
 *  @author Jing Xuan Yew (n10426787)
 */

public class SQLTestCase {
    // Mock Maze Object
    private static final Maze maze1 = new Maze("Maze1", "John Smith", 10, 10, 5, null);
    private static final Maze maze2 = new Maze("Maze2", "Jane Doe", 20, 5, 2, null);
    private static final Maze maze3 = new Maze("Maze3", "Joseph Joestar", 69, 12, 3,null);

    final mazeDataBase dataBase = new mazeDataBase();

    /**
     * Test db.props
     *
     */
    @Test
    public void DBProps() throws IOException {
        String fileLocation;
        String true_url="jdbc:mariadb://localhost:3306";
        String true_schema="mazeco";
        String true_username="mazeco";
        String true_password="hdsajkhd";
        if (Objects.equals(System.getProperty("os.name"), "Windows")) {
            fileLocation = System.getProperty("user.dir") + "\\src\\DBUtils\\db.props";
        } else {
            fileLocation = System.getProperty("user.dir") + "/src/DBUtils/db.props";
        }
        FileInputStream in = new FileInputStream(fileLocation);
        Properties props = new Properties();
        props.load(in);
        in.close();
        String url = props.getProperty("jdbc.url");
        String username = props.getProperty("jdbc.username");
        String password = props.getProperty("jdbc.password");
        String schema = props.getProperty("jdbc.schema");
        assertAll(
                () -> assertEquals(true_url, url),
                () -> assertEquals(true_schema, schema),
                () -> assertEquals(true_username, username),
                () -> assertEquals(true_password, password)
        );
    }

    /**
     * Test createMaze() method that creates a new maze entry in database
     *
     */
    @Test
    public void InsertMazeTest() throws SQLException {
        int mazeID;
        Maze mazeInsertTest;
        try{
            dataBase.disableAutoCommit();
            dataBase.createMaze(maze1);

            mazeID = dataBase.getMazeId(maze1.getName());
            mazeInsertTest = dataBase.getMaze(mazeID);

            assertEquals(maze1.getName(), mazeInsertTest.getName());
            assertEquals(maze1.getAuthor(), mazeInsertTest.getAuthor());
            assertEquals(maze1.getWidth(), mazeInsertTest.getWidth());
            assertEquals(maze1.getHeight(), mazeInsertTest.getHeight());

        } catch (SQLException | IOException e) {
            e.printStackTrace();
        } finally {
            dataBase.rollBack();
        }
    }

    /**
     * Test deleteMaze() method which deletes a maze from database
     *
     */
    @Test
    public void DropMazeTest() throws SQLException, IOException {
        int mazeID;
        // Create a new maze entry in the database
        dataBase.createMaze(maze2);
        // Get mazeID of created maze
        mazeID = dataBase.getMazeId(maze2.getName());
        // Delete maze with mazeID
        dataBase.deleteMaze(mazeID);
        // Delete Maze returns false if there is no rows available to delete
        assertEquals(dataBase.deleteMaze(mazeID), false);

    }

    /**
     * Test getMazeObject(int maze_id) method which
     * retrieves and returns a Maze Object from the database
     */
    @Test
    public void GetMazeObjectTest() throws SQLException {
        try {
            dataBase.disableAutoCommit();

            dataBase.createMaze(maze1);
            dataBase.createMaze(maze2);
            dataBase.createMaze(maze3);

            Maze testMaze = dataBase.getMazeObject(dataBase.getMazeId(maze1.getName()));

            assertEquals(maze1.getName(), testMaze.getName());
            assertEquals(maze1.getAuthor(), testMaze.getAuthor());

        } catch (SQLException | IOException e) {
            e.printStackTrace();
        } finally {
            dataBase.rollBack();
            dataBase.dropTable();
        }
    }

    /**
     * Test getMazeList() method which retrieves and returns a list of all mazes name from the database
     *
     */
    @Test
    public void MazeNamesListTest() throws SQLException {
        mazeDataBase testDataBase = new mazeDataBase();
        try{
            testDataBase.disableAutoCommit();
            testDataBase.createMaze(maze1);
            testDataBase.createMaze(maze2);
            testDataBase.createMaze(maze3);

            Set<String> mazes = testDataBase.getMazeList();

            String[] test = {"Maze1", "Maze2", "Maze3"};
            Set<String> testResult = new TreeSet<>(Arrays.asList(test));
            assertEquals(mazes, testResult);
            assertEquals(mazes.size(), testResult.size());
            //noinspection OptionalGetWithoutIsPresent
            assertEquals(testDataBase.getMazeId(mazes.stream().findFirst().get()), testDataBase.getMazeId(testResult.stream().findFirst().get()));
        }catch (SQLException | IOException e){
            e.printStackTrace();
        } finally {
            testDataBase.rollBack();
            testDataBase.dropTable();
        }
    }

    /**
     * Test searchTable(maze_name) method which retrieves and returns a single table row data of the given maze name from database
     *
     */
    @Test
    public void SearchSingleMazeTest() throws SQLException {
        mazeDataBase testDataBase = new mazeDataBase();
        try {
            testDataBase.disableAutoCommit();
            testDataBase.createMaze(maze1);
            testDataBase.createMaze(maze2);
            testDataBase.createMaze(maze3);

            // Returns 1 row table with ID, Author and Name only
            DefaultTableModel searchMaze1 = testDataBase.searchTable(maze1.getName());

            assertAll(
                    // Check ID
                    () -> assertEquals(searchMaze1.getValueAt(0, 0), testDataBase.getMazeId(maze1.getName())),
                    // Check Author
                    () -> assertEquals(searchMaze1.getValueAt(0, 1), maze1.getAuthor()),
                    // Check Name
                    () -> assertNotEquals(searchMaze1.getValueAt(0, 2), maze2.getName())
            );

        } catch (SQLException | IOException e) {
            e.printStackTrace();
        } finally {
            testDataBase.rollBack();
            testDataBase.dropTable();
        }
    }
    /**
     * Test getTable() method which retrieves and returns a table containing all mazes from database
     *
     */
    @Test
    public void SearchAllMazeTest() throws SQLException {
        mazeDataBase testDataBase = new mazeDataBase();
        try {
            testDataBase.disableAutoCommit();
            testDataBase.createMaze(maze1);
            testDataBase.createMaze(maze2);
            testDataBase.createMaze(maze3);

            // Returns all rows in mazeco table with ID, Author and Name only
            DefaultTableModel searchMaze = testDataBase.getTable();

            assertAll(
                    // Check row count
                    () -> assertEquals(searchMaze.getRowCount(), 3),
                    // Check ID for maze1 (row 1)
                    () -> assertEquals(searchMaze.getValueAt(0, 0), testDataBase.getMazeId(maze1.getName())),
                    // Check Author for maze 1 (row 1)
                    () -> assertEquals(searchMaze.getValueAt(0, 1), maze1.getAuthor()),
                    // Check Name for maze 1 not equal to maze 2 (row 1)
                    () -> assertNotEquals(searchMaze.getValueAt(0, 2), maze2.getName()),
                    // Check maze2 (row 2)
                    () -> assertEquals(searchMaze.getValueAt(1, 1), maze2.getAuthor()),
                    // Check maze3 (row 3)
                    () -> assertEquals(searchMaze.getValueAt(2, 1), maze3.getAuthor())
            );

        } catch (SQLException | IOException e) {
            e.printStackTrace();
        } finally {
            testDataBase.rollBack();
            testDataBase.dropTable();
        }
    }

}
