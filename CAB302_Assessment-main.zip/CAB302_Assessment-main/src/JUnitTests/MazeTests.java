package JUnitTests;

import MazeUtils.MazeDataTypes.AutoMaze;
import MazeUtils.MazeDataTypes.Logo;
import MazeUtils.MazeDataTypes.Maze;
import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Testing suite for the MazeUtils package
 *
 * @author Ben Dundon
 */
public class MazeTests {
    private static final String name = "Test Maze";
    private static final String author = "John Smith";
    private static final int height = 10;
    private static final int width = 10;
    private static final int cellSize = 1;
    private static final Logo logo = null;

    // Test to ensure a created blank maze is actually blank
    @Test
    public void CreateBlankMazeTest() {
        Maze maze = new Maze();
        assertNull(maze.getName());
    }

    // Test to ensure all variables are set correctly in a created maze
    @Test
    public void MazeName() {
        Maze maze = new Maze(name, author, height, width, cellSize, logo);
        assertEquals(name, maze.getName());
    }

    @Test
    public void MazeAuthor() {
        Maze maze = new Maze(name, author, height, width, cellSize, logo);
        assertEquals(author, maze.getAuthor());
    }

    @Test
    public void MazeHeight() {
        Maze maze = new Maze(name, author, height, width, cellSize, logo);
        assertEquals(height, maze.getHeight());
    }

    @Test
    public void MazeWidth() {
        Maze maze = new Maze(name, author, height, width, cellSize, logo);
        assertEquals(width, maze.getWidth());
    }

    @Test
    public void MazeCellSize() {
        Maze maze = new Maze(name, author, height, width, cellSize, logo);
        assertEquals(cellSize, maze.getCellSize());
    }

    // Test for exception handling
    @Test
    public void badHeightMax() {
        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () -> new Maze(name, author, 103, width, cellSize, logo));
        assertEquals("Illegal height (Must be below 100)", thrown.getMessage());
    }

    @Test
    public void badHeightMin() {
        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () -> new Maze(name, author, 0, width, cellSize, logo));
        assertEquals("Illegal height (Must be at least 1)", thrown.getMessage());
    }

    @Test
    public void badWidthMax() {
        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () -> new Maze(name, author, height, 103, cellSize, logo));
        assertEquals("Illegal width (Must be below 100)", thrown.getMessage());
    }

    @Test
    public void badWidthMin() {
        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () -> new Maze(name, author, height, 0, cellSize, logo));
        assertEquals("Illegal width (Must be at least 1)", thrown.getMessage());
    }

    @Test
    public void lastEditTime() {
        Maze maze = new Maze(name, author, height, width, cellSize, logo);
        maze.setLastEditTime();
        assertNotEquals(maze.getLastEditTime(), maze.getCreateTime());
    }

    @Test
    public void specificLastEditTime() {
        Maze maze = new Maze(name, author, height, width, cellSize, logo);
        maze.setLastEditTime();
        LocalDateTime test = LocalDateTime.now();
        maze.setLastEditTime(test);
        assertEquals(test, maze.getLastEditTime());
    }

    @Test
    public void grandfatherParadox() {
        LocalDateTime test = LocalDateTime.now();
        Maze maze = new Maze(name, author, height, width, cellSize, logo);
        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () -> maze.setLastEditTime(test));
        assertEquals("Cannot be edited before creation time", thrown.getMessage());
    }

    @Test
    public void timeTravelEdit() {
        Maze maze = new Maze(name, author, height, width, cellSize, logo);
        LocalDateTime test = LocalDateTime.now();
        maze.setLastEditTime();
        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () -> maze.setLastEditTime(test));
        assertEquals("Cannot be edited before last edit time", thrown.getMessage());
    }

    @Test
    public void blankMazeTimestamp() {
        Maze maze = new Maze();
        assertAll(
                () -> assertNull(maze.getCreateTime()),
                () -> assertNull(maze.getLastEditTime())
        );
    }

    @Test
    public void illegalName() {
        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () -> new Maze("", author, height, width, cellSize, logo));
        assertEquals("Maze title cannot be empty!", thrown.getMessage());
    }

    @Test
    public void setIllegalName() {
        Maze maze = new Maze(name, author, height, width, cellSize, logo);
        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () -> maze.setName(""));
        assertEquals("Maze title cannot be empty!", thrown.getMessage());
    }

    @Test
    public void illegalAuthor() {
        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () -> new Maze(name, "", height, width, cellSize, logo));
        assertEquals("Maze author cannot be empty!", thrown.getMessage());
    }

    @Test
    public void setIllegalAuthor() {
        Maze maze = new Maze(name, author, height, width, cellSize, logo);
        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () -> maze.setAuthor(""));
        assertEquals("Maze author cannot be empty!", thrown.getMessage());
    }

    @Test
    public void illegalCellSize() {
        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () -> new Maze(name,author,height,width, 100,logo));
        assertEquals("Illegal cell size (Must be at most 50)", thrown.getMessage());
    }

    // Auto-maze test
    @Test
    public void autoMazeDifficulty() {
        int difficulty = 10;
        AutoMaze maze = new AutoMaze(name, author, height, width, cellSize, difficulty, logo);
        assertEquals(difficulty, maze.getDifficulty());
    }

    @Test
    public void difficultyException() {
        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () -> new AutoMaze(name, author, height, width, cellSize, 150, logo));
        assertEquals("Illegal difficulty (Must be between 0 and 100)", thrown.getMessage());
    }

    @Test
    public void mazeGeneration() {
        int difficulty = 10;
        AutoMaze maze = new AutoMaze(name, author, height, width, cellSize, difficulty, logo);
        assertNull(maze.getCellGrid());
        maze.setCellGrid(maze.generateMaze(maze));
        assertNotNull(maze.getCellGrid());
    }
}
