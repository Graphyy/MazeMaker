-- This code will set up the required database and user with required permissions --
-- Run as root (or sufficiently privileged user) on Database server --
CREATE USER IF NOT EXISTS `mazeco`@localhost IDENTIFIED BY 'hdsajkhd';
CREATE DATABASE IF NOT EXISTS `mazeco`;
GRANT ALL PRIVILEGES ON mazeco.* to `mazeco`@localhost;